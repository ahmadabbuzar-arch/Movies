var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
var _0x4d7322 = _0x5931;
(function(_0x274395, _0x42d5c2) {
  var _0x5a6e0b = { _0x535452: 566, _0x3f0ba1: 516, _0x449d58: 575, _0x246868: 513, _0x58f74c: 493 }, _0x1fad9e = _0x5931, _0x45ac1a = _0x274395();
  while (!![]) {
    try {
      var _0x159651 = -parseInt(_0x1fad9e(494)) / 1 * (parseInt(_0x1fad9e(512)) / 2) + parseInt(_0x1fad9e(_0x5a6e0b._0x535452)) / 3 + -parseInt(_0x1fad9e(_0x5a6e0b._0x3f0ba1)) / 4 * (parseInt(_0x1fad9e(519)) / 5) + parseInt(_0x1fad9e(552)) / 6 + parseInt(_0x1fad9e(541)) / 7 * (-parseInt(_0x1fad9e(_0x5a6e0b._0x449d58)) / 8) + -parseInt(_0x1fad9e(_0x5a6e0b._0x246868)) / 9 + parseInt(_0x1fad9e(_0x5a6e0b._0x58f74c)) / 10 * (parseInt(_0x1fad9e(539)) / 11);
      if (_0x159651 === _0x42d5c2)
        break;
      else
        _0x45ac1a["push"](_0x45ac1a["shift"]());
    } catch (_0x21869f) {
      _0x45ac1a["push"](_0x45ac1a["shift"]());
    }
  }
})(_0x27f4, 135446);
var __async2 = (_0x17326d, _0x3bf1f8, _0x9587a8) => {
  return new Promise((_0x370d04, _0x1b7722) => {
    var _0x10c202 = _0x5931, _0x4088dc = (_0x43429a) => {
      try {
        _0x259de0(_0x9587a8["next"](_0x43429a));
      } catch (_0x54d9d2) {
        _0x1b7722(_0x54d9d2);
      }
    }, _0x157564 = (_0x54cc36) => {
      var _0x34a148 = _0x5931;
      try {
        _0x259de0(_0x9587a8[_0x34a148(569)](_0x54cc36));
      } catch (_0x41b979) {
        _0x1b7722(_0x41b979);
      }
    }, _0x259de0 = (_0x1f9f9b) => _0x1f9f9b[_0x10c202(564)] ? _0x370d04(_0x1f9f9b[_0x10c202(565)]) : Promise[_0x10c202(560)](_0x1f9f9b["value"])["then"](_0x4088dc, _0x157564);
    _0x259de0((_0x9587a8 = _0x9587a8[_0x10c202(520)](_0x17326d, _0x3bf1f8))["next"]());
  });
}, PROVIDER_NAME = _0x4d7322(488), DESIFLIX_BASE = "https://manifest.desitvhub.eu.org", TMDB_API_KEY = "1865f43a0549ca50d341dd9ab8b29f49", FETCH_TIMEOUT = 12e3, USER_AGENT = _0x4d7322(546);
function log(_0x59bee8) {
  console["log"]("[" + PROVIDER_NAME + "] " + _0x59bee8);
}
function err(_0x5738fe) {
  var _0x222701 = { _0x243566: 573 }, _0x4244da = _0x4d7322;
  console[_0x4244da(_0x222701._0x243566)]("[" + PROVIDER_NAME + "] " + _0x5738fe);
}
function _0x5931(_0x231e7e, _0x4320d7) {
  _0x231e7e = _0x231e7e - 485;
  var _0x27f487 = _0x27f4();
  var _0x5931a0 = _0x27f487[_0x231e7e];
  if (_0x5931["ivjWSM"] === void 0) {
    var _0x285f6b = function(_0x39a065) {
      var _0x7b51e2 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
      var _0x17326d = "", _0x3bf1f8 = "";
      for (var _0x9587a8 = 0, _0x370d04, _0x1b7722, _0x4088dc = 0; _0x1b7722 = _0x39a065["charAt"](_0x4088dc++); ~_0x1b7722 && (_0x370d04 = _0x9587a8 % 4 ? _0x370d04 * 64 + _0x1b7722 : _0x1b7722, _0x9587a8++ % 4) ? _0x17326d += String["fromCharCode"](255 & _0x370d04 >> (-2 * _0x9587a8 & 6)) : 0) {
        _0x1b7722 = _0x7b51e2["indexOf"](_0x1b7722);
      }
      for (var _0x157564 = 0, _0x259de0 = _0x17326d["length"]; _0x157564 < _0x259de0; _0x157564++) {
        _0x3bf1f8 += "%" + ("00" + _0x17326d["charCodeAt"](_0x157564)["toString"](16))["slice"](-2);
      }
      return decodeURIComponent(_0x3bf1f8);
    };
    _0x5931["tOfbOo"] = _0x285f6b, _0x5931["gSBcIf"] = {}, _0x5931["ivjWSM"] = !![];
  }
  var _0x2de63d = _0x27f487[0], _0x1837e9 = _0x231e7e + _0x2de63d, _0x2c12f1 = _0x5931["gSBcIf"][_0x1837e9];
  return !_0x2c12f1 ? (_0x5931a0 = _0x5931["tOfbOo"](_0x5931a0), _0x5931["gSBcIf"][_0x1837e9] = _0x5931a0) : _0x5931a0 = _0x2c12f1, _0x5931a0;
}
function raceTimeout(_0x31afe2) {
  var _0x49ec66 = { _0x331f6b: 486 };
  return new Promise(function(_0x256f83, _0x3b6322) {
    setTimeout(function() {
      var _0x44c5ad = _0x5931;
      _0x3b6322(new Error(_0x44c5ad(_0x49ec66._0x331f6b) + _0x31afe2 + "ms"));
    }, _0x31afe2);
  });
}
function fetchJson(_0x568905) {
  var _0x986e8e = { _0x3b2ab1: 500, _0x291655: 517 };
  return __async2(this, null, function* () {
    var _0x1d0b41 = _0x5931;
    try {
      var _0x4f618d = fetch(_0x568905, { "headers": { "User-Agent": USER_AGENT, "Accept": _0x1d0b41(533) } }), _0x3a7a18 = yield Promise["race"]([_0x4f618d, raceTimeout(FETCH_TIMEOUT)]);
      if (_0x3a7a18 && _0x3a7a18["ok"])
        return yield _0x3a7a18[_0x1d0b41(_0x986e8e._0x3b2ab1)]();
    } catch (_0x365175) {
      err("fetch failed: " + _0x568905 + _0x1d0b41(_0x986e8e._0x291655) + (_0x365175["message"] || ""));
    }
    return null;
  });
}
function _0x27f4() {
  var _0x2b69a5 = ["ihr5Cgu9", "mZG5mZzNz0X6t3G", "tva0", "BwfSyxLHBgfT", "vgLTzw91Dca", "l3n0CMvHBs9ZzxjPzxmV", "rgvZAuzSAxG", "D2vICMLW", "C3bSAxq", "p2fWAv9RzxK9", "zxH0zxjUywXvCMW", "mJbbCfflr0C", "mZC0vw1IywjQ", "mJe2mha", "ihm9", "C29YDa", "ihWG8j+sVIa", "DxjS", "ANnVBG", "Agv2yW", "uMvXDwvZDdOGDg1KyKLKpq", "EwvHCG", "nZiWCa", "qufd", "8j+tPsbxruiTreW", "rg9SyNKGvMLZAw9U", "ihWG8j+tPIa", "lM1Wna", "Edi2nq", "zgrWiduUmq", "mte4r3b5D1ft", "mtCYodCYow9NCevwrq", "ChvZAa", "BMfTzq", "ntzXrNvzzLG", "ic0+ia", "rw5NBgLZAa", "nJm3nJvgBe1AsKq", "yxbWBhK", "DgvSDwD1", "mta4ma", "ndGWCa", "Aw1KyL9Pza", "vgvSDwD1", "zMLYC3rFywLYx2rHDgu", "BgvUz3rO", "Dg9mB3DLCKnHC2u", "ndGW", "mJe2ma", "mta4mha", "Adi2nq", "yxbWBgLJyxrPB24VANnVBG", "AgrYAxa", "Dhj1zwHK", "nY4X", "8j+oPsa", "t3jPz2LUywW", "mZqXmZeZnxHTAwLXBq", "lMPZB24", "mJu5BKjRteDt", "ihWG8j+mIca", "CgfKu3rHCNq", "8j+sVYbcBhvsyxK", "zg9SyNKGDMLZAw9U", "tw96AwXSys81lJaGkfDPBMrVD3mGtLqGmtaUmdSGv2LUnJq7ihG2ncKGqxbWBgvxzwjlAxqVntm3lJm2icHlsfrntcWGBgLRzsbhzwnRBYKGq2HYB21LlZeYnc4WlJaUmcbtywzHCMKVntm3lJm2", "sevwqYb4mJy0", "tM8GC3rYzwfTCYbYzxr1CM5LzcbMCM9TierLC2LgBgL4", "AgrY", "igu9", "8j+nVYa", "mZaZnZq0wuXryLPf", "zxH0zxjUywXFAwrZ", "vhj1zuHe", "zgq1lJe", "vgfTAwW", "Aw1KyKLK", "ihWG8j+oPYa", "ihnVCNrLzcbZDhjLyw1Z", "CMvZB2X2zq", "rgvZAuzSAxGGvgL0Bgu", "DgL0Bgu", "ihWG8j+uIIa", "zg9Uzq", "DMfSDwu", "mteXmdyWzfLHDMT3", "DgfTAwW", "sevwqYb4mJy1", "DgHYB3C", "zw5NBgLZAa", "C3rYzwfTCW", "Aw5KzxHpzG", "zxjYB3i"];
  _0x27f4 = function() {
    return _0x2b69a5;
  };
  return _0x27f4();
}
function getTMDBDetails(_0xecda0e, _0x24c07e) {
  var _0x21122e = { _0x1e2887: 491, _0x59edc8: 561, _0x49ad48: 526, _0x27b1c1: 490, _0x556d57: 553, _0x47c6de: 524 };
  return __async2(this, null, function* () {
    var _0x35b860 = _0x5931, _0x259e30 = _0x24c07e === "tv" || _0x24c07e === "series", _0x482a5c = _0x259e30 ? "tv" : "movie", _0x40b2a9 = "https://api.tmdb.org/3/" + _0x482a5c + "/" + _0xecda0e + _0x35b860(_0x21122e._0x1e2887) + TMDB_API_KEY + "&append_to_response=external_ids", _0x12ce82 = yield fetchJson(_0x40b2a9);
    if (!_0x12ce82)
      return { "title": "DesiFlix Title", "year": "", "imdbId": null };
    return { "title": (_0x259e30 ? _0x12ce82["name"] : _0x12ce82[_0x35b860(562)]) || _0x35b860(_0x21122e._0x59edc8), "year": (_0x259e30 ? _0x12ce82[_0x35b860(_0x21122e._0x49ad48)] || "" : _0x12ce82["release_date"] || "")[_0x35b860(_0x21122e._0x27b1c1)]("-")[0], "imdbId": _0x12ce82["imdb_id"] || _0x12ce82[_0x35b860(_0x21122e._0x556d57)] && _0x12ce82[_0x35b860(553)][_0x35b860(_0x21122e._0x47c6de)] || null };
  });
}
function parseLanguage(_0x5efffd) {
  var _0x9cda3f = { _0x439681: 572, _0x1c2964: 570, _0x40cd7d: 518, _0x409340: 567, _0x110108: 572 }, _0x265e8b = _0x4d7322;
  if (_0x5efffd[_0x265e8b(_0x9cda3f._0x439681)]("multi") !== -1)
    return "Multi-Audio";
  var _0x421a93 = _0x5efffd["indexOf"](_0x265e8b(_0x9cda3f._0x1c2964)) !== -1 || _0x5efffd["indexOf"]("eng") !== -1, _0x2d30d3 = _0x5efffd["indexOf"]("hindi") !== -1 || _0x5efffd[_0x265e8b(572)]("hin") !== -1;
  if (_0x421a93 && _0x2d30d3 || _0x5efffd[_0x265e8b(_0x9cda3f._0x439681)]("dual") !== -1)
    return "Dual-Audio";
  if (_0x2d30d3)
    return "Hindi";
  if (_0x421a93)
    return _0x265e8b(_0x9cda3f._0x40cd7d);
  if (_0x5efffd["indexOf"](_0x265e8b(_0x9cda3f._0x409340)) !== -1)
    return _0x265e8b(556);
  if (_0x5efffd[_0x265e8b(_0x9cda3f._0x110108)](_0x265e8b(521)) !== -1)
    return _0x265e8b(525);
  if (_0x5efffd["indexOf"](_0x265e8b(485)) !== -1)
    return "Malayalam";
  if (_0x5efffd["indexOf"]("kannada") !== -1)
    return "Kannada";
  return _0x265e8b(538);
}
function buildDropdownMetadata(_0x3da196, _0x32fbf3, _0x103e2a, _0x4c6362, _0xae78a2, _0x229e52) {
  var _0x1614b3 = { _0x3b03c9: 561, _0x34bb7b: 503, _0x18b68a: 515, _0x3f9fbc: 528, _0x11b24c: 543, _0x4f7c0d: 530, _0x42d51e: 572, _0x3265d0: 563, _0x9260b1: 501, _0x5595df: 510, _0x3fcd32: 568, _0x5cfc99: 532, _0x4876fc: 510, _0x284eed: 511, _0x589648: 554, _0x10985f: 537, _0x2ce49b: 558, _0x22dac6: 506, _0x59c289: 572, _0x5014cc: 572, _0x1455c5: 576, _0x33f56f: 572, _0x51cd1f: 549, _0x349993: 572, _0x2db75e: 545, _0x39eb40: 508 }, _0x45e741 = _0x4d7322, _0x2c722e = _0x3da196["title"] || _0x45e741(_0x1614b3._0x3b03c9), _0x146dbe = _0x3da196["year"] ? " (" + _0x3da196[_0x45e741(_0x1614b3._0x34bb7b)] + ")" : "", _0x5dee21 = (_0x229e52[_0x45e741(562)] || "") + " " + (_0x229e52[_0x45e741(_0x1614b3._0x18b68a)] || "") + " " + (_0x229e52["url"] || ""), _0x4bc44d = _0x5dee21[_0x45e741(_0x1614b3._0x3f9fbc)](), _0x59c9bb = _0x45e741(551) + _0x2c722e + _0x146dbe;
  _0x103e2a && _0x4c6362 != null && _0xae78a2 != null && (_0x59c9bb += " | S" + String(_0x4c6362)[_0x45e741(_0x1614b3._0x11b24c)](2, "0") + "E" + String(_0xae78a2)[_0x45e741(543)](2, "0"));
  var _0x1abd08 = "\u{1F48E}";
  if (_0x32fbf3["indexOf"](_0x45e741(_0x1614b3._0x4f7c0d)) !== -1 || _0x32fbf3[_0x45e741(_0x1614b3._0x42d51e)]("4k") !== -1)
    _0x1abd08 = "\u{1F31F}";
  else {
    if (_0x32fbf3["indexOf"](_0x45e741(522)) !== -1)
      _0x1abd08 = "\u{1F525}";
  }
  var _0xa6bb03 = parseLanguage(_0x4bc44d), _0x573257 = _0x4bc44d["match"](/(\d+(?:\.\d+)?\s*(?:gb|mb))/i), _0x2dac7d = _0x573257 ? _0x573257[1]["toUpperCase"]() : "Variable Size", _0x430b04 = _0x1abd08 + " " + _0x32fbf3 + _0x45e741(498) + _0x2dac7d + _0x45e741(_0x1614b3._0x3265d0) + _0xa6bb03, _0x261585 = "x264";
  if (_0x4bc44d["indexOf"](_0x45e741(_0x1614b3._0x9260b1)) !== -1 && (_0x4bc44d["indexOf"](_0x45e741(_0x1614b3._0x5595df)) !== -1 || _0x4bc44d["indexOf"](_0x45e741(532)) !== -1))
    _0x261585 = _0x45e741(_0x1614b3._0x3fcd32);
  else {
    if (_0x4bc44d["indexOf"](_0x45e741(_0x1614b3._0x9260b1)) !== -1)
      _0x261585 = _0x45e741(547);
    else
      (_0x4bc44d[_0x45e741(_0x1614b3._0x42d51e)](_0x45e741(510)) !== -1 || _0x4bc44d[_0x45e741(572)](_0x45e741(_0x1614b3._0x5cfc99)) !== -1) && (_0x261585 = _0x45e741(_0x1614b3._0x4876fc));
  }
  var _0x176bed = _0x45e741(505);
  if (_0x4bc44d["indexOf"]("ddp5.1") !== -1 || _0x4bc44d["indexOf"](_0x45e741(_0x1614b3._0x284eed)) !== -1)
    _0x176bed = "DDP5.1";
  else {
    if (_0x4bc44d["indexOf"](_0x45e741(555)) !== -1 || _0x4bc44d["indexOf"]("5.1") !== -1)
      _0x176bed = "DD5.1";
    else {
      if (_0x4bc44d[_0x45e741(572)](_0x45e741(536)) !== -1)
        _0x176bed = "7.1";
      else {
        if (_0x4bc44d["indexOf"](_0x45e741(535)) !== -1)
          _0x176bed = _0x45e741(_0x1614b3._0x589648);
      }
    }
  }
  var _0x4cf26b = _0x4bc44d[_0x45e741(572)]("atmos") !== -1 ? " | \u{1F50A} Atmos" : "", _0x4831c7 = _0x45e741(_0x1614b3._0x10985f) + _0x261585 + _0x45e741(_0x1614b3._0x2ce49b) + _0x176bed + _0x4cf26b, _0x2f930f = _0x45e741(_0x1614b3._0x22dac6);
  if (_0x4bc44d["indexOf"]("web-rip") !== -1 || _0x4bc44d[_0x45e741(_0x1614b3._0x42d51e)](_0x45e741(489)) !== -1)
    _0x2f930f = "\u{1F310} WEB-RIP";
  else {
    if (_0x4bc44d[_0x45e741(_0x1614b3._0x42d51e)]("bluray") !== -1)
      _0x2f930f = _0x45e741(544);
    else {
      if (_0x4bc44d[_0x45e741(_0x1614b3._0x59c289)](_0x45e741(534)) !== -1)
        _0x2f930f = "\u{1F4FA} HD-RIP";
    }
  }
  var _0x83022b = _0x229e52["url"] && _0x229e52["url"][_0x45e741(_0x1614b3._0x5014cc)](_0x45e741(509)) !== -1 ? _0x45e741(_0x1614b3._0x1455c5) : "MKV", _0x4fac72 = "SDR";
  if (_0x4bc44d["indexOf"]("10bit") !== -1 || _0x4bc44d[_0x45e741(_0x1614b3._0x33f56f)]("10-bit") !== -1)
    _0x4fac72 = _0x4bc44d[_0x45e741(572)](_0x45e741(_0x1614b3._0x51cd1f)) !== -1 ? "10bit HDR" : "10bit";
  else {
    if (_0x4bc44d["indexOf"]("hdr10+") !== -1)
      _0x4fac72 = "HDR10+";
    else {
      if (_0x4bc44d[_0x45e741(572)]("hdr") !== -1)
        _0x4fac72 = "HDR";
      else
        (_0x4bc44d["indexOf"]("dv") !== -1 || _0x4bc44d[_0x45e741(_0x1614b3._0x349993)](_0x45e741(_0x1614b3._0x2db75e)) !== -1) && (_0x4fac72 = _0x45e741(507));
    }
  }
  var _0x18afa2 = _0x2f930f + _0x45e741(_0x1614b3._0x39eb40) + _0x83022b + _0x45e741(542) + _0x4fac72, _0x30e4f1 = "\u{1F4CE} " + PROVIDER_NAME;
  return _0x59c9bb + " " + _0x430b04 + " " + _0x4831c7 + " " + _0x18afa2 + " " + _0x30e4f1;
}
function getStreams(_0x151035, _0x1d5d5f, _0x4a4a6f, _0xe39a47) {
  var _0x1d3ba2 = { _0x376f8b: 574, _0x3e88d4: 550, _0x234014: 571, _0x5f2b9a: 548, _0x5036b8: 499, _0x5a64b4: 492, _0xe7a027: 562, _0x537b91: 514 }, _0x2bcd9a = { _0x3f06da: 515 }, _0x29df05 = { _0x448346: 572, _0x266da8: 572 };
  return __async2(this, null, function* () {
    var _0x2cbeaf = _0x5931, _0x30b586 = _0x1d5d5f === "tv" || _0x1d5d5f === "series";
    log(_0x2cbeaf(502) + _0x151035 + _0x2cbeaf(_0x1d3ba2._0x376f8b) + _0x1d5d5f + _0x2cbeaf(496) + _0x4a4a6f + _0x2cbeaf(_0x1d3ba2._0x3e88d4) + _0xe39a47);
    var _0x21d9e5 = yield getTMDBDetails(_0x151035, _0x1d5d5f), _0xcfc11 = _0x21d9e5["imdbId"] || _0x151035, _0x5e2034 = "";
    if (_0x30b586) {
      var _0x8318cb = _0x4a4a6f != null ? _0x4a4a6f : 1, _0x476b1f = _0xe39a47 != null ? _0xe39a47 : 1;
      _0x5e2034 = DESIFLIX_BASE + "/stream/series/" + _0xcfc11 + ":" + _0x8318cb + ":" + _0x476b1f + ".json";
    } else
      _0x5e2034 = DESIFLIX_BASE + "/stream/movie/" + _0xcfc11 + _0x2cbeaf(540);
    log("Fetching streams from: " + _0x5e2034);
    var _0x1ff470 = yield fetchJson(_0x5e2034);
    if ((!_0x1ff470 || !_0x1ff470[_0x2cbeaf(571)] || !_0x1ff470[_0x2cbeaf(571)]["length"]) && _0x21d9e5[_0x2cbeaf(557)]) {
      var _0x11e4d1 = _0x30b586 ? DESIFLIX_BASE + _0x2cbeaf(487) + _0x151035 + ":" + (_0x4a4a6f || 1) + ":" + (_0xe39a47 || 1) + ".json" : DESIFLIX_BASE + "/stream/movie/" + _0x151035 + ".json";
      log("Retrying with fallback endpoint: " + _0x11e4d1), _0x1ff470 = yield fetchJson(_0x11e4d1);
    }
    if (!_0x1ff470 || !_0x1ff470[_0x2cbeaf(571)] || !_0x1ff470[_0x2cbeaf(_0x1d3ba2._0x234014)][_0x2cbeaf(527)])
      return log(_0x2cbeaf(_0x1d3ba2._0x5f2b9a)), [];
    var _0x143585 = [], _0x4c94ec = {};
    for (var _0x217402 = 0; _0x217402 < _0x1ff470[_0x2cbeaf(_0x1d3ba2._0x234014)]["length"]; _0x217402++) {
      var _0x2af0ce = _0x1ff470["streams"][_0x217402], _0x336fb5 = _0x2af0ce[_0x2cbeaf(_0x1d3ba2._0x5036b8)] || _0x2af0ce[_0x2cbeaf(_0x1d3ba2._0x5a64b4)];
      if (!_0x336fb5 || _0x4c94ec[_0x336fb5])
        continue;
      _0x4c94ec[_0x336fb5] = !![];
      var _0x387647 = ((_0x2af0ce[_0x2cbeaf(_0x1d3ba2._0xe7a027)] || "") + " " + (_0x2af0ce["name"] || "") + " " + _0x336fb5)["toLowerCase"](), _0xf21667 = "1080p";
      if (_0x387647[_0x2cbeaf(572)]("2160") !== -1 || _0x387647["indexOf"]("4k") !== -1)
        _0xf21667 = _0x2cbeaf(495);
      else {
        if (_0x387647["indexOf"]("720") !== -1)
          _0xf21667 = "720p";
        else {
          if (_0x387647[_0x2cbeaf(572)](_0x2cbeaf(529)) !== -1)
            _0xf21667 = "480p";
        }
      }
      var _0x5c0eb6 = parseLanguage(_0x387647), _0x2ae4a4 = buildDropdownMetadata(_0x21d9e5, _0xf21667, _0x30b586, _0x4a4a6f, _0xe39a47, _0x2af0ce);
      _0x143585[_0x2cbeaf(_0x1d3ba2._0x537b91)]({ "name": PROVIDER_NAME + " | " + _0xf21667 + " | " + _0x5c0eb6, "title": _0x2ae4a4, "size": _0x2ae4a4, "description": _0x2ae4a4, "url": _0x336fb5, "quality": "", "language": "", "headers": { "User-Agent": USER_AGENT, "Referer": DESIFLIX_BASE + "/" } });
    }
    function _0x413fb1(_0x2c8dd3) {
      var _0x59eef5 = _0x2cbeaf, _0x5af0d2 = _0x2c8dd3["toLowerCase"]();
      if (_0x5af0d2[_0x59eef5(_0x29df05._0x448346)]("2160p") !== -1 || _0x5af0d2[_0x59eef5(572)]("4k") !== -1)
        return 2160;
      if (_0x5af0d2[_0x59eef5(_0x29df05._0x266da8)](_0x59eef5(531)) !== -1)
        return 1080;
      if (_0x5af0d2["indexOf"](_0x59eef5(504)) !== -1)
        return 720;
      if (_0x5af0d2[_0x59eef5(_0x29df05._0x266da8)](_0x59eef5(523)) !== -1)
        return 480;
      return 0;
    }
    return _0x143585[_0x2cbeaf(497)](function(_0x44ed16, _0x240b31) {
      var _0x373e3e = _0x2cbeaf;
      return _0x413fb1(_0x240b31["name"]) - _0x413fb1(_0x44ed16[_0x373e3e(_0x2bcd9a._0x3f06da)]);
    }), log("Returning " + _0x143585["length"] + _0x2cbeaf(559)), _0x143585;
  });
}
typeof module !== "undefined" && module["exports"] ? module["exports"] = { "getStreams": getStreams } : global["getStreams"] = getStreams;
(function() {
  var _origGetStreams = typeof module !== "undefined" && module.exports && module.exports.getStreams || (typeof getStreams === "function" ? getStreams : typeof global !== "undefined" ? global.getStreams : null);
  if (typeof _origGetStreams !== "function")
    return;
  var TMDB_API_KEY_WRAP = "1865f43a0549ca50d341dd9ab8b29f49";
  var PROVIDER_NAME2 = "DesiFlix";
  var PROVIDER_ID = "desiflix";
  var DEFAULT_LANG = "\u{1F1EE}\u{1F1F3} Hindi Dub";
  function formatCholeCard(opt) {
    var raw = [opt.filename || "", opt.rawText || "", opt.server || "", opt.quality || "", opt.size || "", opt.title || ""].join(" ");
    var text = raw.trim();
    var cleanText = text.replace(/4khdhub/gi, "").replace(/hdhub4u/gi, "");
    var res = "";
    var qCheck = opt.quality ? String(opt.quality).trim() : "";
    if (/\b(?:2160p|4k|uhd)\b/i.test(qCheck))
      res = "4K UHD";
    else if (/\b(?:1080p|fhd)\b/i.test(qCheck))
      res = "1080p FHD";
    else if (/\b(?:720p|hd)\b/i.test(qCheck))
      res = "720p HD";
    else if (/\b(?:480p|sd)\b/i.test(qCheck))
      res = "480p";
    else if (/\b(?:2160p|4k|uhd)\b/i.test(cleanText))
      res = "4K UHD";
    else if (/\b(?:1080p|fhd)\b/i.test(cleanText))
      res = "1080p FHD";
    else if (/\b(?:720p|hd)\b/i.test(cleanText))
      res = "720p HD";
    else if (/\b(?:480p|sd)\b/i.test(cleanText))
      res = "480p";
    else
      res = qCheck ? qCheck.toUpperCase() : "1080p FHD";
    var source = "";
    if (/\bremux\b/i.test(text))
      source = "REMUX";
    else if (/\b(?:bluray|bdrip|brrip)\b/i.test(text))
      source = "BluRay";
    else if (/\b(?:web-?dl|webrip|web)\b/i.test(text))
      source = "WEB-DL";
    else if (/\bhdtv\b/i.test(text))
      source = "HDTV";
    var codecs = [];
    if (/\b(?:hevc|x265|h\.?265)\b/i.test(text))
      codecs.push("HEVC");
    else if (/\b(?:x264|h\.?264|avc)\b/i.test(text))
      codecs.push("x264");
    if (/\b10-?bit\b/i.test(text))
      codecs.push("10-bit");
    var hdr = [];
    if (/\b(?:dolby\s*vision|dv)\b/i.test(text))
      hdr.push("Dolby Vision");
    if (/\bhdr10\+\b/i.test(text))
      hdr.push("HDR10+");
    else if (/\b(?:hdr10|hdr)\b/i.test(text))
      hdr.push("HDR");
    var audio = [];
    var hasAtmos = /\b(?:atmos|ddpa)\b/i.test(text);
    var hasTrueHD = /\btruehd\b/i.test(text);
    var hasDTSHD = /\bdts-?hd(?:\s*ma)?\b/i.test(text);
    var hasDTS = /\bdts\b/i.test(text);
    var hasDDP = /\b(?:ddp|dd\+|eac3)\b/i.test(text);
    var hasDD = /\b(?:dd|ac3)\b/i.test(text);
    var has71 = /7\.1/i.test(text);
    var has51 = /5\.1/i.test(text);
    if (hasAtmos)
      audio.push("Dolby Atmos" + (has71 ? " 7.1" : has51 ? " 5.1" : ""));
    else if (hasTrueHD)
      audio.push("TrueHD" + (has71 ? " 7.1" : has51 ? " 5.1" : ""));
    else if (hasDTSHD)
      audio.push("DTS-HD MA" + (has71 ? " 7.1" : has51 ? " 5.1" : ""));
    else if (hasDTS)
      audio.push("DTS" + (has51 ? " 5.1" : ""));
    else if (hasDDP)
      audio.push("DDP 5.1");
    else if (hasDD)
      audio.push("DD 5.1");
    else if (/\baac\b/i.test(text))
      audio.push("AAC");
    var langs = [];
    if (/\b(?:hindi|hin)\b/i.test(text))
      langs.push("\u{1F1EE}\u{1F1F3} Hindi");
    if (/\b(?:tamil|tam)\b/i.test(text))
      langs.push("\u{1F1EE}\u{1F1F3} Tamil");
    if (/\b(?:telugu|tel)\b/i.test(text))
      langs.push("\u{1F1EE}\u{1F1F3} Telugu");
    if (/\b(?:english|eng)\b/i.test(text))
      langs.push("\u{1F1EC}\u{1F1E7} English");
    if (/\b(?:korean|kor)\b/i.test(text))
      langs.push("\u{1F1F0}\u{1F1F7} Korean");
    if (/\b(?:japanese|jap|jpn)\b/i.test(text))
      langs.push("\u{1F1EF}\u{1F1F5} Japanese");
    if (/\bdual[- ]?audio\b/i.test(text))
      langs.push("\u{1F310} Dual-Audio");
    if (/\bmulti[- ]?audio\b/i.test(text))
      langs.push("\u{1F310} Multi-Audio");
    if (langs.length === 0 && opt.defaultLang) {
      langs.push(opt.defaultLang);
    }
    var uniqueLangs = Array.from(new Set(langs));
    var sizeMatch = text.match(/(?:💾\s*|\[|\b)([0-9.]+\s*[GM]B)(?:\]|\b)/i);
    var rawSize = opt.size && !opt.size.includes("\n") ? opt.size : sizeMatch ? sizeMatch[1] : "";
    var size = rawSize ? rawSize.replace(/([0-9.]+)\s*([GM]B)/i, "$1 $2").toUpperCase() : "";
    var server = opt.server || "";
    if (!server) {
      var grpMatch = text.match(/-([a-zA-Z0-9_]+)(?:\.[a-z]{3})?$/i);
      if (grpMatch && grpMatch[1].length > 2 && grpMatch[1].length < 15)
        server = grpMatch[1];
    }
    var nameParts = [];
    if (opt.latency)
      nameParts.push("\u{1F7E2} FAST (" + opt.latency + "ms)");
    nameParts.push(opt.provider || "Stream");
    if (server)
      nameParts.push("\u{1F3F7}\uFE0F " + server);
    if (res)
      nameParts.push(res);
    if (source)
      nameParts.push(source);
    if (codecs.length)
      nameParts.push(codecs.join(" "));
    if (hdr.length)
      nameParts.push(hdr.join(" "));
    if (audio.length)
      nameParts.push(audio[0]);
    if (uniqueLangs.length) {
      var dualTag = uniqueLangs.find(function(l) {
        return l.indexOf("Dual") !== -1 || l.indexOf("Multi") !== -1;
      });
      if (dualTag)
        nameParts.push(dualTag);
      else
        nameParts.push(uniqueLangs.slice(0, 2).join(" + "));
    }
    if (opt.seeders !== void 0 && opt.seeders !== null && opt.seeders !== "") {
      nameParts.push("\u{1F331} " + opt.seeders);
    }
    var nameLine = nameParts.join(" \u2022 ");
    var filename = (opt.filename || "").trim();
    if (!filename || filename === opt.title) {
      var baseTitle = (opt.title || "Video").replace(/[^a-zA-Z0-9]+/g, ".");
      var yr = opt.year ? "." + opt.year : "";
      var se = opt.season && opt.episode ? ".S" + String(opt.season).padStart(2, "0") + "E" + String(opt.episode).padStart(2, "0") : "";
      var r = res ? "." + res.replace(/\s+/g, ".") : "";
      var s = source ? "." + source : "";
      var c = codecs.length ? "." + codecs.join(".") : "";
      var a = audio.length ? "." + audio[0].replace(/[^a-zA-Z0-9]+/g, ".") : "";
      var g = server ? "-" + server.replace(/[\s\-_]+/g, "") : "-" + (opt.provider || "Release");
      filename = baseTitle + yr + se + r + s + c + a + g + ".mkv";
    }
    var specTags = [res, source].concat(codecs).filter(Boolean);
    var seasonEp = opt.season && opt.episode ? " \u2022 S" + String(opt.season).padStart(2, "0") + "E" + String(opt.episode).padStart(2, "0") : "";
    var line1 = "\u{1F3AC} " + (opt.title || "Unknown") + (opt.year ? " (" + opt.year + ")" : "") + seasonEp + (specTags.length ? " [" + specTags.join(" \u2022 ") + "]" : "");
    var line2 = "\u{1F4C4} " + filename;
    var av = hdr.concat(audio);
    var line3 = av.length ? "\u{1F48E} " + av.join(" \u2022 ") : "";
    var line4 = uniqueLangs.length ? "\u{1F310} " + uniqueLangs.join(" \u2022 ") : "";
    var meta = [];
    if (size)
      meta.push("\u{1F4E6} " + size);
    if (opt.seeders !== void 0 && opt.seeders !== null && opt.seeders !== "")
      meta.push("\u{1F7E2} " + opt.seeders + " Seeders");
    if (server)
      meta.push("\u{1F3F7}\uFE0F " + server);
    meta.push("\u{1F517} " + (opt.provider || "Stream"));
    var line5 = meta.join(" \u2022 ");
    var body = [line1, line2, line3, line4, line5].filter(Boolean).join(" ");
    var qualitySlug = "1080p";
    if (res.indexOf("4K") !== -1 || res.indexOf("2160") !== -1)
      qualitySlug = "4k";
    else if (res.indexOf("1080") !== -1)
      qualitySlug = "1080p";
    else if (res.indexOf("720") !== -1)
      qualitySlug = "720p";
    else if (res.indexOf("480") !== -1)
      qualitySlug = "480p";
    return {
      name: body,
      description: body,
      title: body,
      quality: qualitySlug,
      size: size || ""
    };
  }
  function wrappedGetStreams(tmdbId, mediaType, season, episode) {
    return __async(this, null, function* () {
      var mediaInfo = { title: "", year: "" };
      try {
        var isSeries = mediaType === "tv" || mediaType === "series";
        var tmdbEndpoint = isSeries ? "tv" : "movie";
        var tmdbUrl = "https://api.tmdb.org/3/" + tmdbEndpoint + "/" + tmdbId + "?api_key=" + TMDB_API_KEY_WRAP;
        var tmdbRes = yield fetch(tmdbUrl, {
          headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36" }
        }).then(function(r) {
          return r.json();
        }).catch(function() {
          return null;
        });
        if (tmdbRes) {
          mediaInfo.title = tmdbRes.title || tmdbRes.name || "";
          var dateStr = tmdbRes.release_date || tmdbRes.first_air_date || "";
          mediaInfo.year = dateStr ? dateStr.split("-")[0] : "";
        }
      } catch (e) {
      }
      var rawStreams = [];
      try {
        rawStreams = yield _origGetStreams(tmdbId, mediaType, season, episode);
      } catch (e) {
        return [];
      }
      if (!Array.isArray(rawStreams) || rawStreams.length === 0)
        return [];
      return rawStreams.map(function(s) {
        if (!s)
          return null;
        var potentialFilename = "";
        if (s.fileName)
          potentialFilename = s.fileName;
        else if (s.filename)
          potentialFilename = s.filename;
        if (!potentialFilename && s.url) {
          try {
            var u = new URL(s.url);
            var uParam = u.searchParams.get("u") || u.searchParams.get("url");
            var targetPath = u.pathname;
            if (uParam) {
              try {
                var parsedTarget = new URL(uParam);
                targetPath = parsedTarget.pathname;
              } catch (e) {
                targetPath = uParam;
              }
            }
            var lastPart = decodeURIComponent(targetPath.split("/").pop() || "");
            if (lastPart && /\.(mkv|mp4|avi|mov|ts)$/i.test(lastPart)) {
              potentialFilename = lastPart;
            }
          } catch (e) {
          }
        }
        if (!potentialFilename && s.title) {
          var infoMatch = s.title.match(/ℹ️\s*([^\n|]+)/);
          if (infoMatch) {
            var rawName = infoMatch[1].trim();
            if (/\.(mkv|mp4|avi|mov)$/i.test(rawName))
              potentialFilename = rawName;
            else
              potentialFilename = rawName.replace(/\s+/g, ".") + ".mkv";
          } else if (/\.(mkv|mp4|avi|mov)$/i.test(s.title.trim())) {
            potentialFilename = s.title.replace(/^🎬\s*/, "").trim();
          } else if (!/[|📺🌐💾🎞️]/.test(s.title) && s.title.length > 8 && !s.title.includes("\n")) {
            potentialFilename = s.title.replace(/^🎬\s*/, "").trim();
          }
        }
        var detectedServer = s.server || "";
        if (!detectedServer && s.name) {
          var srvMatch = s.name.match(/(?:Server\s*\d+|G-Direct|V-Cloud|HubCloud|Driveseed|Worker|FSLv2)/i);
          if (srvMatch)
            detectedServer = srvMatch[0];
        }
        if (!detectedServer && s.title) {
          var titleSrvMatch = s.title.match(/(?:Server\s*\d+|📌\s*Server\s*\d+)/i);
          if (titleSrvMatch)
            detectedServer = titleSrvMatch[0].replace(/[📌\s]+/g, " ").trim();
        }
        var finalTitle = mediaInfo.title;
        if (!finalTitle && s.title) {
          var firstLine = s.title.split("\n")[0].replace(/^🎬\s*/, "").replace(/\s*-\s*\d{4}.*$/, "").replace(/\s*\(\d{4}\).*$/, "").trim();
          if (firstLine && !/unknown/i.test(firstLine))
            finalTitle = firstLine;
        }
        if (!finalTitle)
          finalTitle = "Video";
        var card = formatCholeCard({
          provider: PROVIDER_NAME2,
          title: finalTitle,
          year: mediaInfo.year || "",
          season: mediaType === "tv" || mediaType === "series" ? season : null,
          episode: mediaType === "tv" || mediaType === "series" ? episode : null,
          filename: potentialFilename,
          server: detectedServer,
          quality: s.quality || "",
          size: s.size || "",
          rawText: (s.name || "") + " " + (s.title || ""),
          defaultLang: DEFAULT_LANG,
          url: s.url
        });
        return Object.assign({}, s, {
          name: card.name,
          title: card.title.replace(/[\r\n]+/g, " "),
          size: (card.size || "").replace(/[\r\n]+/g, " "),
          description: card.title.replace(/[\r\n]+/g, " "),
          quality: card.quality || s.quality,
          provider: PROVIDER_ID
        });
      }).filter(Boolean);
    });
  }
  if (typeof module !== "undefined" && module.exports) {
    module.exports.getStreams = wrappedGetStreams;
    if (typeof onSettings !== "undefined")
      module.exports.onSettings = onSettings;
  }
  if (typeof globalThis !== "undefined")
    globalThis.getStreams = wrappedGetStreams;
  if (typeof global !== "undefined")
    global.getStreams = wrappedGetStreams;
})();
