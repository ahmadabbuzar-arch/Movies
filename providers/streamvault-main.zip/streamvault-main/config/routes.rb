Rails.application.routes.draw do
  devise_for :users, controllers: { registrations: "users/registrations" }

  # Root
  root "home#index"

  # Search
  resources :search, only: [ :index ]

  # Content detail
  get "content/:type/:imdb_id", to: "content#show", as: :content
  get "content/:type/:imdb_id/status", to: "content#status", as: :content_status
  get "content/:type/:imdb_id/episode_streams", to: "content#episode_streams", as: :episode_streams

  # Collection
  resources :library, only: [ :index ]
  resources :wishlist, only: [ :index ]
  resource :collection, only: [ :update ]

  # Watch History
  resources :watch_history, only: [ :index, :destroy ] do
    collection do
      delete :clear_all
    end
  end


  # Streaming
  resources :streaming, only: [ :create, :show ] do
    collection do
      get :resume
      post :stall_telemetry
    end
    member do
      patch :progress
      get :next_episode
    end
  end

  # FFmpeg transcode proxy (MKV → fMP4 with AAC audio)
  get "transcode/duration", to: "transcode_duration#show", as: :transcode_duration
  get "transcode/tracks", to: "transcode_tracks#show", as: :transcode_tracks
  get "transcode/seek", to: "transcode_tracks#seek", as: :transcode_seek
  get "transcode/subtitles", to: "transcode_subtitles#show", as: :transcode_subtitles
  get "transcode", to: "transcode#stream", as: :transcode_stream

  # HLS streaming (iOS fallback — iPhone Safari lacks MSE support)
  post "hls/start", to: "hls#start", as: :hls_start
  get "hls/:id/playlist.m3u8", to: "hls#playlist", as: :hls_playlist
  get "hls/:id/:segment", to: "hls#segment", as: :hls_segment, constraints: { segment: /\d+\.ts/ }
  post "hls/:id/stop", to: "hls#stop", as: :hls_stop

  # Settings
  get "settings", to: "settings#show", as: :settings
  patch "settings", to: "settings#update"

  # Direct stream proxy (bypass ffmpeg for browser-compatible content)
  get "direct_stream", to: "direct_stream#show", as: :direct_stream

  # Health check
  get "up" => "rails/health#show", as: :rails_health_check
end
