require 'rails_helper'

RSpec.describe "Home", type: :request do
  let(:user) { create(:user) }
  let(:cache) { ActiveSupport::Cache::MemoryStore.new }

  before do
    allow(Rails).to receive(:cache).and_return(cache)
    # Stub all Cinemeta catalog endpoints used by HomeController
    %w[movie series].each do |type|
      %w[top year imdbRating].each do |cat|
        stub_request(:get, %r{v3-cinemeta\.strem\.io/catalog/#{type}/#{cat}})
          .to_return(status: 200, body: { "metas" => [] }.to_json, headers: { 'Content-Type' => 'application/json' })
      end
    end

    # TMDB not configured in tests — RecommendationService returns []
    ENV["TMDB_READ_ACCESS_TOKEN"] = ""
  end

  describe "Continue Watching removal" do
    before { sign_in user }

    it "item disappears from Continue Watching after delete" do
      # With the upsert design, one row per content.
      inception = create(:playback_progress, :movie, user: user, imdb_id: "tt1375666",
        title: "Inception", progress_seconds: 3_600, duration_seconds: 7_200, watched_at: 1.minute.ago)
      create(:playback_progress, :movie, user: user, imdb_id: "tt0903747",
        title: "Breaking Bad", progress_seconds: 1_200, duration_seconds: 6_000, watched_at: 2.minutes.ago)

      # Pre-condition: both titles appear on home.
      get root_path
      expect(response.body).to include("Inception")
      expect(response.body).to include("Breaking Bad")
      # The delete button must target the entry's id (history_id).
      expect(response.body).to include("watch_history/#{inception.id}")

      # Delete the Continue Watching item.
      delete watch_history_path(inception), headers: { "HTTP_REFERER" => root_path }

      # Post-condition: Inception is gone, Breaking Bad remains.
      get root_path
      expect(response.body).not_to include("Inception")
      expect(response.body).to include("Breaking Bad")
    end
  end

  describe "Continue Watching episode advancement" do
    before { sign_in user }

    it "renders the next episode for a completed episode" do
      create(:playback_progress, :episode, user: user, imdb_id: "tt0903747",
        title: "Breaking Bad", progress_seconds: 2_400, duration_seconds: 2_400, watched_at: 1.minute.ago)
      stub_request(:get, %r{v3-cinemeta\.strem\.io/meta/series/tt0903747\.json})
        .to_return(status: 200, body: {
          "meta" => {
            "id" => "tt0903747",
            "name" => "Breaking Bad",
            "videos" => [
              { "season" => 1, "episode" => 1, "id" => "tt0903747001", "name" => "Pilot", "released" => "2008-01-20" },
              { "season" => 1, "episode" => 2, "id" => "tt0903747002", "name" => "Cat's in the Bag...", "released" => "2008-01-27" }
            ]
          }
        }.to_json, headers: { "Content-Type" => "application/json" })

      get root_path

      expect(response).to have_http_status(:ok)
      expect(response.body).to include("S01E02")
    end
  end

  describe "GET /" do
    context "when not authenticated" do
      it "redirects to login" do
        get root_path
        expect(response).to redirect_to(new_user_session_path)
      end
    end

    context "when authenticated" do
      before { sign_in user }

      it "returns success" do
        get root_path
        expect(response).to have_http_status(:ok)
      end

      it "does not show another user's cached recommendations" do
        other_user = create(:user)
        cache.write("recommendations/user/#{other_user.id}", [
          { tmdb_id: 1, imdb_id: "tt0000123", title: "OTHER_USER_REC_TITLE", type: "movie" }
        ])

        get root_path

        expect(response.body).not_to include("OTHER_USER_REC_TITLE")
      end

      it "filters watched titles from cached recommendations" do
        create(:playback_progress, user: user, imdb_id: "tt0468569")
        cache.write("recommendations/user/#{user.id}", [
          { tmdb_id: 1, imdb_id: "tt0468569", title: "ALREADY_WATCHED_REC", type: "movie" },
          { tmdb_id: 2, imdb_id: "tt0000123", title: "UNSEEN_REC", type: "movie" }
        ])

        get root_path

        expect(response.body).not_to include("ALREADY_WATCHED_REC")
        expect(response.body).to include("UNSEEN_REC")
      end
    end
  end
end
