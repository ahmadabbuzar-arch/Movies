# Vega App Provider Extensions

# Provider

How providers are structured and how to create a new one.

## Provider Folder Structure

Each provider lives in its own folder under `providers/`:

```
providers/
  myProvider/
    catalog.ts
    meta.ts
    posts.ts
    stream.ts
    episodes.ts (optional)
    settings.ts (optional)
```

Provider icons are stored as optimized square PNG files in `assets/` and are
referenced through stable jsDelivr URLs in `manifest.json`. Keep the manifest
`icon` empty only when a provider intentionally has no icon.

Provider modules are bundled during the build so internal imports (e.g. `./parsers/*`)
are supported without relying on runtime `require()` in the app.

## File Explanations

### 1. `catalog.ts`

<img src="https://github.com/user-attachments/assets/40e5da3d-326d-4f5c-b266-a4167da2a269" width="200"/>

- **Purpose:** Defines the categories or filters available for your provider.
- **How it's used:**
  - The `title` property will be shown as the heading on the home page (e.g., "Popular Movies").
  - The `filter` property is passed to the `getPosts` function in `posts.ts`.
  - For example, if you define `{ title: "Popular Movies", filter: "/category/popular-movies" }`, then home-page heading will show "Popular Movies" and `/category/popular-movies` will be sent to `getPosts` as the `filter` argument. Your `getPosts` implementation should use this to fetch and return the relevant items (e.g., popular movies).
- The same logic applies to `genres`: each genre object has a `title` (displayed as a heading) and a `filter` (used to fetch genre-specific items).
- **Exports:**
  - `catalog`: An array of objects with `title` and `filter` fields.
  - `genres`: (optional) An array for genre filters.
- **Optional i18n fields (app-side translation):**
  - `titleKey` + `titleParams` can be provided alongside `title` so the app can localize labels.
- **AnimeUnity advanced filters:**
  - The `filter` string can include query params for AnimeUnity to drive `top-anime` and `archivio` filters.
  - Examples:
    - `top?status=In%20Corso&order=most_viewed`
    - `archive?type=TV&order=Valutazione`

### 2. `meta.ts`

- **Purpose:** Fetches metadata for a specific item (movie, show, etc.).
- **Exports:**
- `getMeta({ link, providerContext })`: Returns an `Info` object with details like title, synopsis, image, etc.

### 3. `posts.ts`

- **Purpose:** Fetches lists of items (posts) and handles search.
- **Exports:**
  - `getPosts({ filter, page, providerValue, signal, providerContext })`: Returns an array of `Post` objects for a given filter and page.
  - `getSearchPosts({ searchQuery, page, providerValue, signal, providerContext })`: (optional) Returns search results as an array of `Post` objects.

### 4. `stream.ts`

- **Purpose:** Fetches streaming links or sources for a given item.
- **Exports:**
  - `getStream({ link, type, signal, providerContext })`: Returns an array of `Stream` objects with streaming info.

### 5. `episodes.ts` (Optional)

- **Purpose:** Handles episode-specific logic for series.
- **When to use:**
  - This file is optional and not required for all providers. Some providers return the full episode list directly in the metadata from `getMeta`, but others require a separate request to fetch episodes for a specific season.
  - If your provider's `getMeta` function cannot return all episodes at once, you can return a `linkList` like this:
    ```js
    linkList: [
      {
        title: "season 1",
        episodesLink: "/season-1",
      },
    ];
    ```
  - When a user selects a season, the `episodesLink` value (e.g., `/season-1`) will be sent as the `url` argument to `getEpisodes` in `episodes.ts`.
  - Your `getEpisodes` function should then fetch and return the list of episodes for that season.
- **Exports:**
  - `getEpisodes({ url, providerContext })`: Returns an array of `EpisodeLink` objects for the given season or episode group.

### 6. `settings.ts` (Optional)

- Add `"hasSettings": true` to the provider entry in `manifest.json`.
- Export `getSettingsSchema({ providerContext })`, returning `SettingsField[]`.
- Supported fields are `text`, `toggle`, `select`, `multiselect`, and `number`.
- Mark secret text fields such as personal API tokens with `secure: true`.
- Read and write values through `providerContext.kvStore`; do not embed credentials in provider code.
- The app scopes and encrypts stored values per provider source and provider. Uninstalling or resetting a provider clears its values.

AnimeUnity, StreamingUnity e StreamCenter offrono una chiave API TMDB v3 opzionale
nelle rispettive impostazioni. La chiave e salvata dall'app nello storage locale
cifrato del singolo provider, non nel manifest o nei bundle. Se presente, i
resolver TMDB interrogano prima l'API mantenendo la priorita linguistica e delle
immagini esistente; per dati mancanti o errori usano le pagine TMDB e poi i
fallback verso gli altri servizi gia previsti dal provider. Senza chiave il
percorso web resta invariato. Le credenziali non vanno incluse nei log o nei
test fixture committati.

L'indice pubblico AniBridge v3 di AnimeUnity e condiviso fra le ricerche
tramite il contesto del provider. Nelle versioni dell'app che espongono
`providerContext.fileCache`, viene salvato su file per 24 ore con la sola
chiave `anibridge-v3`; il provider valida sempre lo schema prima di usarlo.
Se la cache e assente, scaduta o non disponibile, il provider scarica e
valida normalmente il dataset. Non salvare questo indice nel KV cifrato delle
impostazioni: e un dataset pubblico e di grandi dimensioni.

```ts
export const getSettingsSchema = async () => [
  {
    key: "apiKey",
    type: "text",
    label: "API Key",
    secure: true,
    defaultValue: "",
  },
];
```

## Internationalization (i18n) fields

The app can localize provider-provided labels when you include optional i18n fields.

- `Catalog`: `titleKey`, `titleParams`
- `Post`: `episodeLabelKey`, `episodeLabelParams` (keep `episodeLabel` as fallback)
- `Link` / `EpisodeLink` / `directLinks`: `titleKey`, `titleParams`
- `Info`: `titleKey`/`titleParams` for fallback titles, `tagKeys` map `{ [rawTag]: i18nKey }` to translate tags in the app

## AnimeUnity TMDB metadata

### Inventari leggeri per il database incrementale di Vega

AnimeUnity, StreamingUnity e StreamCenter espongono facoltativamente `getContentInventory({link, providerContext})` e `getEpisodeInventory({url, providerContext})`. Restituiscono solo stato, disponibilità, stagioni e identificatori degli episodi presenti sul provider, senza riavviare la ricerca TMDB/TVDB/AniZip per gli episodi già salvati. L'inventario episodi di StreamingUnity riguarda soltanto la stagione selezionata. `getEpisodes` accetta `knownEpisodes` opzionale e arricchisce i soli episodi nuovi. StreamCenter delega gli inventari al provider di origine e ricostruisce i propri percorsi di riproduzione; i vecchi chiamanti che non passano `knownEpisodes` mantengono il comportamento completo.

Gli inventari incompleti generano un errore: l'app conserva i dati precedenti invece di interpretare una risposta parziale come rimozione di contenuti. Queste API opzionali non cambiano la gerarchia di artwork e metadati.

AnimeUnity resolves AniBridge TMDB IDs through the reusable modules in
`providers/animeunity/tmdb/`. The scraper uses public TMDB pages and does not
embed an API token. TMDB artwork follows Italian, English, original language,
then TMDB's no-language (`xx`) assets. Inside the selected language the scraper
preserves TMDB's gallery popularity order without re-ranking by resolution.
Logos are the deliberate exception: Italian, English, then no-language; the
original language is not queried for logos.

The normal AnimeUnity flow only projects the TMDB fields consumed by Vega:
title logo, poster, backdrop, and localized episode title, synopsis, and
thumbnail. Posters use an unambiguous AniBridge season scope when available,
then fall back to general TMDB artwork. Episode fields are resolved independently:
TMDB is primary and AniZip supplies only missing titles (`it`, then `en`),
English `overview` text, and TheTVDB thumbnails. AniZip `summary` is ignored.
The large raw TMDB/AniZip objects are not added to `Info.extra` or `EpisodeLink`.
Season links preserve AnimeUnity's absolute episode numbers because TMDB uses
the same numbering for these split anime seasons. Direct AniBridge ranges take
priority over ranges discovered by reverse lookup. AniZip fallback matching
uses the JSON episode key first, avoiding duplicated or shifted nested TVDB
numbers.

Title-level artwork and IMDb lookups only use AniBridge targets attached
directly to the requested AniList/MAL work. Reverse-discovered related works
remain available for episode relationships but cannot replace the movie or
series identity used for metadata. When an exact TMDB target is absent, AniZip
can still supply one for the requested AniList/MAL IDs.

Artwork fallback requests are conditional. Logos use TMDB, Cinemeta, TVDB,
AniZip, then the provider. After an image-load failure, Vega may call
`getArtwork({fields: ["logo"], failedUrls})`: AnimeUnity skips the failed URLs
and resolves the next source only then, while StreamCenter forwards AnimeUnity
routes to the same resolver. A missing or failed logo does not change the
language priority or poster selection. Backgrounds are composed with the app as provider, AniList
banner, TMDB, Cinemeta, AniZip Fanart, then AniZip Banner. External metadata
uses persistent cache entries with bounded refresh windows, and AniZip episode
data is refreshed early when the provider episode count changes.

StreamingUnity keeps provider poster/background artwork first, then exposes
TMDB and TVDB candidates. Logos intentionally use TMDB, then TVDB,
then the provider candidate; Vega inserts Cinemeta before the provider logo.
The returned `extra.artworkSources` value always identifies the selected URL,
while `extra.artworkCandidates` preserves every available ordered fallback.

The reusable resolver still supports complete title metadata on demand by
calling `resolveTmdbMediaMetadata` with `includeExtended: true`. Season artwork
and episode lists are loaded only when that season is requested, and all TMDB
requests share the provider runtime cache.

## `providerContext`?

`providerContext` is an object passed to each function, providing shared utilities and dependencies, such as:

- `axios`: For HTTP requests
- `cheerio`: For HTML parsing
- `getBaseUrl`: Helper to get the provider's base URL. For providers listed in `providers/baseUrlRegistry.ts` (es. animeunity), it uses Pastebin first and falls back to a hardcoded URL. Other providers still use modflix.json.
- `commonHeaders`: Standard HTTP headers
- `extractors`: Shared extractor functions
- `Aes`: (if needed) for encryption/decryption
- `kvStore`: Provider-scoped persistent settings and state (`get`, `set`, `delete`, `keys`, `clear`)

This ensures all providers use the same tools and patterns, making code easier to maintain and extend.

## Reference Types

All function signatures and return types should use the interfaces from `providers/types.ts`:

- `Post`, `Info`, `Stream`, `EpisodeLink`, etc.

## Example: `posts.ts`

```ts
import { Post, ProviderContext } from "../types";

export const getPosts = async function ({
  filter,
  page,
  providerValue,
  signal,
  providerContext,
}: {
  filter: string;
  page: number;
  providerValue: string;
  signal: AbortSignal;
  providerContext: ProviderContext;
}): Promise<Post[]> {
  // ...implementation...
};

export const getSearchPosts = async function ({
  searchQuery,
  page,
  providerValue,
  signal,
  providerContext,
}: {
  searchQuery: string;
  page: number;
  providerValue: string;
  signal: AbortSignal;
  providerContext: ProviderContext;
}): Promise<Post[]> {
  // ...implementation...
};
```

## Example: `catalog.ts`

```ts
// catalog.ts
export const catalog = [
  { title: "Popular Movies", filter: "/category/popular-movies" },
  { title: "Latest TV Shows", filter: "/category/latest-tv-shows" },
];

export const genres = [
  { title: "Action", filter: "/genre/action" },
  { title: "Drama", filter: "/genre/drama" },
];
```

## Example: `meta.ts`

```ts
// meta.ts
import { Info, ProviderContext } from "../types";

export const getMeta = async function ({
  link,
  providerContext,
}: {
  link: string;
  providerContext: ProviderContext;
}): Promise<Info> {
  // Fetch and parse metadata for the item
  // ...implementation...
  return {
    title: "Example Movie",
    synopsis: "A sample synopsis.",
    image: "https://example.com/image.jpg",
    imdbId: "tt1234567",
    type: "movie",
    linkList: [],
  };
};
```

## Example: `stream.ts`

```ts
// stream.ts
import { Stream, ProviderContext } from "../types";

export const getStream = async function ({
  link,
  type,
  signal,
  providerContext,
}: {
  link: string;
  type: string;
  signal: AbortSignal;
  providerContext: ProviderContext;
}): Promise<Stream[]> {
  // Fetch and return streaming sources
  // ...implementation...
  return [
    {
      server: "ExampleServer",
      link: "https://example.com/stream.m3u8",
      type: "m3u8",
      quality: "1080",
    },
  ];
};
```

## Example: `episodes.ts` (Optional)

```ts
// episodes.ts
import { EpisodeLink, ProviderContext } from "../types";

export const getEpisodes = async function ({
  url,
  providerContext,
}: {
  url: string;
  providerContext: ProviderContext;
}): Promise<EpisodeLink[]> {
  // Fetch and return episode links
  // ...implementation...
  return [
    { title: "Episode 1", link: "https://example.com/ep1" },
    { title: "Episode 2", link: "https://example.com/ep2" },
  ];
};
```

## About `linkList` in `meta.ts`

The `linkList` property in the object returned by `getMeta` is used to describe available seasons, episodes, or direct download/stream links for the item.

<img src="https://github.com/user-attachments/assets/f5dc31fc-0701-4d97-8056-01a58ecdefc0" width="200"/>

- Each entry in `linkList` can represent a season or anything you want; it will be shown in the dropdown.
- If your provider requires an extra request to fetch episodes for a season, set the `episodesLink` property. When the user selects that season, the app will call `getEpisodes` with this value.
- If your provider does not require an extra request (i.e., you already have all episode links), you can return them directly in the `directLinks` array. Each `directLinks` entry should have a `link`, `title`, and `type` (e.g., "movie" or "series").
- The `quality` property can be used to indicate video quality (e.g., "1080").

### Example

```js
linkList: [
  {
    title: "Season 2",
    episodesLink: "",
    directLinks: [
      {
        link: "https://example.com/download",
        title: "Episode 1",
        type: "movie",
      },
      // ...more episodes or links
    ],
    quality: "1080",
  },
];
```

- If you use `directLinks`, the app will send the selected link directly to `getStream` when needed, skipping the need for an extra episode request.
- If you use `episodesLink`, the app will call `getEpisodes` to fetch the episode list for that season or group.

This gives you flexibility to support both providers that need extra requests for episodes and those that can return all links up front.

## How to Test Your Provider

AnimeUnity and StreamingUnity finish the same metadata lookups and fallbacks as
before, but independent Info requests can now overlap: related titles/trailers,
artwork, season layout and availability checks no longer have to wait for one
another unnecessarily. A TMDB API key still falls back to web scraping for
missing artwork fields only; it does not change the image or language priority.
Run `npm run test:meta:critical-path` to check the overlap and the resulting
Info data, alongside the provider-specific metadata tests.

1. **Start the Dev Server**

   - Run the following command in your terminal:
     ```sh
     npm run auto
     ```
   - This will start the development server and log a "Mobile test url" (e.g., `http://<your-local-ip>:3001`).

2. **Configure the Vega App for Local Testing**

   - Open your Vega app project.
   - Go to `src/lib/services/ExtensionManager.ts`.
   - Set the following variables in class ExtensionManager:
     ```ts
     private testMode = true;
     private baseUrlTestMode = "http://<your-local-ip>:3001"; // Use the Mobile test url from the dev server
     ```
   - This tells the app to use your local providers for testing.

3. **Network Requirement**

   - Make sure both your development machine (running the dev server) and your mobile device (running the Vega app) are on the same network.

4. **Test in the App**
   - App will now use your local provider code for all requests.

---

This workflow allows you to quickly test and debug new providers before deploying them.

Follow this structure and naming convention to ensure your provider integrates smoothly with the project.
