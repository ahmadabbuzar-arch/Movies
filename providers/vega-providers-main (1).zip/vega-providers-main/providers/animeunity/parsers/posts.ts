import { Post, ProviderContext } from "../../types";
import { buildAnimeLink, decodeHtmlAttribute, normalizeImageUrl } from "../utils";
import {
  AnimeVariantEntry,
  deduplicateAnimeVariantPosts,
  isDubbedAnimeVariant,
} from "../variants";

const CALENDAR_DAY_MAP: Record<string, string> = {
  lunedi: "Monday",
  "lunedì": "Monday",
  monday: "Monday",
  martedi: "Tuesday",
  "martedì": "Tuesday",
  tuesday: "Tuesday",
  mercoledi: "Wednesday",
  "mercoledì": "Wednesday",
  wednesday: "Wednesday",
  giovedi: "Thursday",
  "giovedì": "Thursday",
  thursday: "Thursday",
  venerdi: "Friday",
  "venerdì": "Friday",
  friday: "Friday",
  sabato: "Saturday",
  saturday: "Saturday",
  domenica: "Sunday",
  sunday: "Sunday",
  indeterminato: "Undetermined",
  indeterminata: "Undetermined",
  undetermined: "Undetermined",
};

export function normalizeCalendarDay(value?: string): string | undefined {
  if (!value) return undefined;
  const normalized = value.trim().toLowerCase();
  if (!normalized) return undefined;
  return CALENDAR_DAY_MAP[normalized] || value;
}

function pickTitle(anime: any): string {
  return (
    anime?.title_eng ||
    anime?.title ||
    anime?.title_it ||
    anime?.name ||
    ""
  );
}

function pickRating(anime: any): string | undefined {
  const value = anime?.score ?? anime?.rating;
  if (value == null) return undefined;
  const normalized = String(value).trim().replace(",", ".");
  if (!normalized) return undefined;
  const parsed = Number(normalized);
  if (!Number.isFinite(parsed) || parsed <= 0) return undefined;
  return normalized;
}

function toPositiveNumber(value: unknown): number | undefined {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : undefined;
}

function buildArtworkHints(anime: any): Post["artworkHints"] {
  const anilistId = toPositiveNumber(anime?.anilist_id ?? anime?.anilistId);
  const malId = toPositiveNumber(anime?.mal_id ?? anime?.malId);
  const rawType = typeof anime?.type === "string" ? anime.type.trim() : "";
  if (!anilistId && !malId) return undefined;
  return {
    anilistId,
    malId,
    isMovie: rawType ? rawType.toLowerCase().includes("movie") : undefined,
  };
}

export function toPost(
  anime: any,
  baseHost: string,
  extra?: Partial<Post>
): Post | null {
  const id = anime?.id;
  const slug = anime?.slug;
  const title = pickTitle(anime);
  const image = normalizeImageUrl(anime?.imageurl || anime?.imageUrl);
  const link = buildAnimeLink(baseHost, id, slug);
  if (!title || !image || !link) {
    return null;
  }
  const dubbed = isDubbedAnimeVariant(anime);
  return {
    title,
    image,
    link,
    artworkHints: buildArtworkHints(anime),
    rating: pickRating(anime),
    dubStatus: dubbed ? "dubbed" : "subbed",
    dubStatusKey: dubbed ? "Dubbed" : "Subbed",
    ...extra,
  };
}

function extractEpisodeNumber(value: unknown): number | null {
  if (value == null) return null;
  if (typeof value === "number" && Number.isFinite(value)) {
    return value >= 0 ? value : null;
  }
  const text = String(value).trim();
  if (!text) return null;
  const match = text.match(/\d+/);
  if (!match) return null;
  const parsed = Number.parseInt(match[0], 10);
  return Number.isFinite(parsed) ? parsed : null;
}

function extractEpisodeNumberFromEpisodes(episodes: any[]): number | null {
  let maxValue: number | null = null;
  episodes.forEach((episode) => {
    if (episode && typeof episode === "object") {
      const raw =
        (episode as any).number ??
        (episode as any).episode ??
        (episode as any).id;
      const candidate = extractEpisodeNumber(raw);
      if (candidate != null && (maxValue == null || candidate > maxValue)) {
        maxValue = candidate;
      }
    }
  });
  return maxValue;
}

function extractEpisodeNumberFromEpisodesDynamic(episodes: any): number | null {
  if (Array.isArray(episodes)) {
    return extractEpisodeNumberFromEpisodes(episodes);
  }
  if (typeof episodes === "string") {
    try {
      const decoded = JSON.parse(episodes);
      if (Array.isArray(decoded)) {
        return extractEpisodeNumberFromEpisodes(decoded);
      }
      if (decoded && typeof decoded === "object" && Array.isArray(decoded.data)) {
        return extractEpisodeNumberFromEpisodes(decoded.data);
      }
    } catch (_) {
      return null;
    }
  }
  if (episodes && typeof episodes === "object" && Array.isArray(episodes.data)) {
    return extractEpisodeNumberFromEpisodes(episodes.data);
  }
  return null;
}

function extractEpisodeNumberFromMap(data: any): number | null {
  if (!data || typeof data !== "object") {
    return null;
  }
  const keys = [
    "number",
    "ep",
    "episodio",
    "episode",
    "episode_number",
    "ep_number",
    "episode_num",
    "last_episode",
    "last_episode_number",
    "last_episode_num",
  ];
  for (const key of keys) {
    if (!(key in data)) {
      continue;
    }
    const value = (data as any)[key];
    if (value && typeof value === "object") {
      const nested = extractEpisodeNumber(
        (value as any).number ?? (value as any).episode ?? (value as any).id
      );
      if (nested != null) {
        return nested;
      }
    }
    const candidate = extractEpisodeNumber(value);
    if (candidate != null) {
      return candidate;
    }
  }
  return null;
}

function buildEpisodeLabel(value: number | null | undefined): string | undefined {
  if (value == null) {
    return undefined;
  }
  return `Ep. ${value}`;
}

type EpisodeLabelInfo = {
  label: string;
  labelKey: string;
  labelParams: { number: number };
};

const EPISODE_LABEL_KEY = "Ep. {{number}}";

function buildEpisodeLabelInfo(
  value: number | null | undefined
): EpisodeLabelInfo | undefined {
  if (value == null) {
    return undefined;
  }
  if (!Number.isFinite(value)) {
    return undefined;
  }
  return {
    label: `Ep. ${value}`,
    labelKey: EPISODE_LABEL_KEY,
    labelParams: { number: value },
  };
}

export function extractLatestEpisodeNumber(item: any): number | null {
  let number = extractEpisodeNumberFromMap(item);
  if (number == null && item?.episode != null) {
    if (item.episode && typeof item.episode === "object") {
      number = extractEpisodeNumber(
        (item.episode as any).number ??
          (item.episode as any).episode ??
          (item.episode as any).id
      );
    } else {
      number = extractEpisodeNumber(item.episode);
    }
  }
  if (number == null) {
    number = extractEpisodeNumberFromEpisodesDynamic(item?.episodes);
  }
  if (number == null && item?.anime && typeof item.anime === "object") {
    number = extractEpisodeNumberFromMap(item.anime);
    if (number == null) {
      number = extractEpisodeNumberFromEpisodesDynamic(item.anime.episodes);
    }
  }
  return number;
}

export function extractCalendarEpisodeNumber(item: any): number | null {
  let publishedCount = extractEpisodeNumberFromEpisodesDynamic(item?.episodes);
  if (publishedCount == null && Number.isFinite(item?.real_episodes_count)) {
    publishedCount = item.real_episodes_count;
  }
  if (publishedCount != null && publishedCount >= 0) {
    return publishedCount + 1;
  }
  const fallback = item?.episodes_count ?? item?.episode_count;
  return extractEpisodeNumber(fallback);
}

export function parseLatestPostsFromHtml(
  html: string,
  cheerio: ProviderContext["cheerio"],
  baseHost: string
): Post[] {
  const $ = cheerio.load(html);
  const raw = $("layout-items").attr("items-json") || "";
  if (!raw) return [];
  const data = JSON.parse(raw);
  const items = data?.data || [];
  const entries: AnimeVariantEntry[] = [];
  items.forEach((item: any) => {
    const episodeNumber = extractLatestEpisodeNumber(item);
    const episodeLabelInfo = buildEpisodeLabelInfo(episodeNumber);
    const episodeId = item?.id;
    const post = toPost(item?.anime ?? item, baseHost, {
      episodeLabel: episodeLabelInfo?.label || buildEpisodeLabel(episodeNumber),
      episodeLabelKey: episodeLabelInfo?.labelKey,
      episodeLabelParams: episodeLabelInfo?.labelParams,
      episodeId,
    });
    if (post) {
      entries.push({ anime: item?.anime ?? item, post });
    }
  });
  return deduplicateAnimeVariantPosts(entries);
}

export function parseTopPostsFromHtml(
  html: string,
  cheerio: ProviderContext["cheerio"],
  baseHost: string
): Post[] {
  const $ = cheerio.load(html);
  const raw = $("top-anime").attr("animes") || "";
  if (!raw) {
    try {
      const hasTopTag = $("top-anime").length > 0;
      console.log("[animeunity][top] missing animes attr", {
        hasTopTag,
        htmlLength: html ? html.length : 0,
      });
    } catch (_) {
      // ignore logging errors
    }
    return [];
  }
  let data: any;
  try {
    const decoded = decodeHtmlAttribute(raw);
    data = JSON.parse(decoded);
  } catch (_) {
    try {
      data = JSON.parse(raw);
    } catch (err) {
      try {
        console.log("[animeunity][top] parse error", {
          rawSample: raw.slice(0, 200),
        });
      } catch (_) {
        // ignore logging errors
      }
      return [];
    }
  }
  const items = Array.isArray(data?.data) ? data.data : [];
  const entries: AnimeVariantEntry[] = [];
  items.forEach((item: any) => {
    const post = toPost(item, baseHost);
    if (post) {
      entries.push({ anime: item, post });
    }
  });
  const posts = deduplicateAnimeVariantPosts(entries);
  if (posts.length === 0) {
    try {
      console.log("[animeunity][top] empty posts", {
        items: items.length,
        htmlLength: html ? html.length : 0,
      });
    } catch (_) {
      // ignore logging errors
    }
  }
  return posts;
}

export function parseCalendarPostsFromHtml(
  html: string,
  cheerio: ProviderContext["cheerio"],
  baseHost: string
): Post[] {
  const $ = cheerio.load(html);
  const entries: AnimeVariantEntry[] = [];
  $("calendario-item").each((_, element) => {
    const raw = $(element).attr("a") || "";
    if (!raw) return;
    const decoded = decodeHtmlAttribute(raw);
    try {
      const data = JSON.parse(decoded);
      const day = normalizeCalendarDay(
        typeof data?.day === "string" ? data.day : undefined
      );
      const episodeNumber = extractCalendarEpisodeNumber(data);
      const episodeLabelInfo = buildEpisodeLabelInfo(episodeNumber);
      const episodeLabel =
        episodeLabelInfo?.label || buildEpisodeLabel(episodeNumber);
      const post = toPost(data, baseHost, {
        day,
        episodeLabel,
        episodeLabelKey: episodeLabelInfo?.labelKey,
        episodeLabelParams: episodeLabelInfo?.labelParams,
      });
      if (post) {
        entries.push({ anime: data, post });
      }
    } catch (_) {
      return;
    }
  });
  return deduplicateAnimeVariantPosts(entries);
}

export function parseArchiveRecords(records: any[], baseHost: string): Post[] {
  const entries: AnimeVariantEntry[] = [];
  records.forEach((item: any) => {
    const post = toPost(item, baseHost);
    if (post) {
      entries.push({ anime: item, post });
    }
  });
  return deduplicateAnimeVariantPosts(entries);
}
