import { ProviderContext } from "../types";

export const DEFAULT_BASE_URL = "";
export const DEFAULT_CDN_URL = "";
export const DEFAULT_LOCALE = "it";
export const REQUEST_TIMEOUT = 15000;

export const normalizeBaseUrl = (value: string): string =>
  value.replace(/\/+$/, "");

const normalizeAbsoluteUrl = (value: unknown): string => {
  const raw = String(value || "").trim();
  if (!raw) return "";
  return raw.replace(/\/+$/, "");
};

export const resolveBaseUrl = async (
  providerContext: ProviderContext
): Promise<string> => {
  try {
    const resolved = await providerContext.getBaseUrl("streamingunity");
    if (resolved) {
      return normalizeBaseUrl(resolved);
    }
  } catch (_) {
    // ignore and fall back to empty base url
  }
  return DEFAULT_BASE_URL;
};

export const deriveCdnUrlFromBaseUrl = (
  baseUrl: string,
  fallback: string = DEFAULT_CDN_URL
): string => {
  const normalizedBase = normalizeAbsoluteUrl(baseUrl);
  if (!normalizedBase) return fallback;

  const candidate = /^https?:\/\//i.test(normalizedBase)
    ? normalizedBase
    : `https://${normalizedBase}`;
  try {
    const parsed = new URL(candidate);
    const hostname = String(parsed.hostname || "")
      .trim()
      .replace(/^www\./i, "");
    if (!hostname) return fallback;
    const cdnHost = hostname.startsWith("cdn.") ? hostname : `cdn.${hostname}`;
    return `https://${cdnHost}`;
  } catch (_) {
    return fallback;
  }
};

export const resolveCdnUrl = (
  payload: any,
  baseUrl: string,
  fallback: string = DEFAULT_CDN_URL
): string => {
  const candidates = [payload?.cdn_url, payload?.cdnUrl, payload?.cdn];
  for (const candidate of candidates) {
    const normalized = normalizeAbsoluteUrl(candidate);
    if (normalized) {
      return normalized;
    }
  }
  return deriveCdnUrlFromBaseUrl(baseUrl, fallback);
};

const withLeadingSlash = (value: string): string =>
  value.startsWith("/") ? value : `/${value}`;

export const buildLocalePath = (path: string): string => {
  const normalized = path ? withLeadingSlash(path.trim()) : "";
  if (!normalized || normalized === "/") {
    return `/${DEFAULT_LOCALE}`;
  }
  if (normalized.startsWith(`/${DEFAULT_LOCALE}/`) || normalized === `/${DEFAULT_LOCALE}`) {
    return normalized;
  }
  return `/${DEFAULT_LOCALE}${normalized}`;
};

export const resolveUrl = (href: string, baseUrl: string): string => {
  if (!href) return "";
  if (/^https?:\/\//i.test(href)) return href;
  return new URL(href, baseUrl).href;
};

export const buildLocaleUrl = (path: string, baseUrl: string): string =>
  resolveUrl(buildLocalePath(path), baseUrl);

export const decodeHtmlEntities = (value: string): string =>
  value
    .replace(/&quot;/g, "\"")
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");

export const extractInertiaPage = (
  html: string,
  cheerio: ProviderContext["cheerio"]
): { props?: any } | null => {
  if (!html) return null;
  const $ = cheerio.load(html);
  const raw =
    $("#app[data-page]").first().attr("data-page") ||
    $("div[data-page]").first().attr("data-page") ||
    "";
  if (!raw) return null;

  const decoded = decodeHtmlEntities(raw);
  try {
    return JSON.parse(decoded);
  } catch (_) {
    try {
      return JSON.parse(decodeHtmlEntities(decoded));
    } catch (err) {
      console.error("streamingunity data-page parse error", err);
      return null;
    }
  }
};

export const getTranslationValue = (
  translations: any[] | undefined,
  key: string,
  locale: string = DEFAULT_LOCALE
): string => {
  if (!Array.isArray(translations)) return "";
  const match = translations.find(
    (item) => item && item.key === key && item.locale === locale
  );
  return match?.value ? String(match.value).trim() : "";
};

export const resolveTitleName = (
  title: any,
  locale: string = DEFAULT_LOCALE
): string => {
  const normalizeSlugTitle = (value: string): string => {
    const raw = String(value || "").trim();
    if (!raw) return "";
    const normalized = raw.replace(/[-_]+/g, " ").replace(/\s+/g, " ").trim();
    if (!normalized) return "";
    return normalized
      .split(" ")
      .map((word) => (word ? word[0].toUpperCase() + word.slice(1) : ""))
      .join(" ");
  };
  const hasLatinChars = (value: string): boolean =>
    /[A-Za-zÀ-ÖØ-öø-ÿ]/.test(value);
  const hasCjkChars = (value: string): boolean =>
    /[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/.test(value);
  const normalizeComparable = (value: string): string =>
    normalizeText(value).toLowerCase();

  const translations = title?.translations;
  const original = String(title?.name || title?.original_name || "").trim();
  const isValidTranslated = (value: string): boolean => {
    if (!value) return false;
    if (!original) return true;
    const sameAsOriginal =
      normalizeComparable(value) === normalizeComparable(original);
    if (sameAsOriginal && hasCjkChars(value)) {
      return false;
    }
    return !sameAsOriginal || hasLatinChars(value);
  };

  const translated = getTranslationValue(translations, "name", locale);
  if (isValidTranslated(translated)) {
    return translated;
  }
  if (locale !== "en") {
    const english = getTranslationValue(translations, "name", "en");
    if (isValidTranslated(english)) {
      return english;
    }
  }
  const slugCandidate =
    getTranslationValue(translations, "slug", locale) ||
    getTranslationValue(translations, "slug", "en") ||
    String(title?.slug || "").trim();
  const normalizedSlug = normalizeSlugTitle(slugCandidate);
  if (normalizedSlug) {
    return normalizedSlug;
  }
  return original;
};

export const resolveTitleSlug = (
  title: any,
  locale: string = DEFAULT_LOCALE
): string => {
  const translated = getTranslationValue(title?.translations, "slug", locale);
  return translated || String(title?.slug || "").trim();
};

export const buildImageUrl = (image: any, cdnUrl: string): string => {
  if (!image) return "";
  const raw =
    image.original_url_field || image.url || image.src || image.path || image.filename || "";
  if (!raw) return "";
  if (/^https?:\/\//i.test(raw)) return raw;
  const normalizedCdn = cdnUrl ? cdnUrl.replace(/\/+$/, "") : "";
  if (!normalizedCdn) return raw;
  return `${normalizedCdn}/images/${String(raw).replace(/^\/+/, "")}`;
};

export const pickImageByType = (
  images: any[] | undefined,
  cdnUrl: string,
  types: string[],
  locale: string = DEFAULT_LOCALE
): string => {
  if (!Array.isArray(images) || images.length === 0) return "";
  const normalizedTypes = types.map((type) => type.toLowerCase());

  for (const type of normalizedTypes) {
    const matches = images.filter(
      (img) => String(img?.type || "").toLowerCase() === type
    );
    if (matches.length === 0) continue;
    const localized = matches.find(
      (img) => String(img?.lang || "").toLowerCase() === locale
    );
    const fallback = localized || matches.find((img) => !img?.lang) || matches[0];
    const url = buildImageUrl(fallback, cdnUrl);
    if (url) return url;
  }

  const fallback = images[0];
  return buildImageUrl(fallback, cdnUrl);
};

export const extractTitleId = (value: string): string => {
  if (!value) return "";
  const cleaned = value.split("::")[0];
  const match = cleaned.match(/\/(?:titles|watch)\/(\d+)/i) ||
    cleaned.match(/^(\d+)$/);
  return match?.[1] || "";
};

export const buildTitleUrl = (
  titleId: string | number,
  slug: string,
  baseUrl: string
): string => {
  const id = String(titleId || "").trim();
  if (!id) return "";
  const safeSlug = slug ? `-${slug}` : "";
  return buildLocaleUrl(`/titles/${id}${safeSlug}`, baseUrl);
};

export const normalizeText = (value: string): string =>
  String(value || "")
    .replace(/\s+/g, " ")
    .trim();
