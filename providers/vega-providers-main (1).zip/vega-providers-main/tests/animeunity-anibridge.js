const assert = require("assert");
const fs = require("fs");
const path = require("path");
const {
  ANIBRIDGE_MAPPINGS_URL,
  PLEXANIBRIDGE_MAPPINGS_URL,
  buildAniBridgeExtra,
  mapAniBridgeEpisodeRange,
  parseAniBridgeDescriptor,
  parseAniBridgePayload,
  resolveAniBridgeEpisodeMappings,
  resolveAnimeMappings,
  resolveExternalAnimeMappings,
} = require("../dist/animeunity/mappings/index.js");
const { getEpisodes } = require("../dist/animeunity/episodes.js");
const { selectPrimaryTmdbId } = require("../dist/animeunity/tmdb/index.js");

const executeVegaBundle = (fileName) => {
  const moduleCode = fs.readFileSync(
    path.join(__dirname, "..", "dist", "animeunity", fileName),
    "utf8",
  );
  const executionContext = {
    exports: {},
    console,
    Promise,
    Object,
  };
  return new Function(
    "context",
    `
      const exports = context.exports;
      const console = context.console;
      const Promise = context.Promise;
      const Object = context.Object;
      ${moduleCode}
      return exports;
    `,
  )(executionContext);
};

const fixture = {
  $meta: {
    schema_version: "3.0.3",
    generated_on: "2026-09-24",
  },
  "anilist:20": {
    "mal:20": {},
    "tmdb_show:46260:s1": { "1-52": "1-52" },
    "tmdb_show:46260:s2": { "53-104": "53-104" },
    "tvdb_show:78857:s2": { "53-104": "1-52" },
  },
  "mal:20": {
    "anilist:20": {},
    "tmdb_show:46260:s2": { "53-104": "53-104" },
  },
  "anilist:5": {
    "imdb_movie:tt0275277": {},
    "tmdb_movie:11299": {},
  },
  "anilist:30": {
    "mal:30": {},
    "tvdb_show:78857:s2": { "1-13": "1-13" },
  },
  "tvdb_show:78857:s2": {
    "anilist:20": { "1-52": "53-104" },
    "tmdb_show:46260:s2": { "1-52": "1-52" },
  },
  "anilist:131573": {
    "imdb_movie:tt14331144": { "1": "1" },
    "mal:48561": { "1": "1" },
    "tmdb_movie:810693": { "1": "1" },
    "tvdb_show:377543:s0": { "1": "2" },
  },
  "mal:48561": {
    "anilist:131573": { "1": "1" },
    "imdb_movie:tt14331144": { "1": "1" },
    "tmdb_movie:810693": { "1": "1" },
    "tvdb_show:377543:s0": { "1": "2" },
  },
  "anilist:192809": {
    "imdb_movie:tt36956670": { "1": "1" },
    "mal:59654": { "1": "1" },
    "tmdb_movie:1338799": { "1": "1" },
    "tvdb_show:377543:s0": { "1": "7" },
  },
  "mal:59654": {
    "anilist:192809": { "1": "1" },
    "imdb_movie:tt36956670": { "1": "1" },
    "tmdb_movie:1338799": { "1": "1" },
    "tvdb_show:377543:s0": { "1": "7" },
  },
  "anidb:99999:R": {
    "anilist:131573": {},
    "anilist:192809": {},
    "imdb_movie:tt14331144": {},
    "imdb_movie:tt36956670": {},
    "mal:48561": {},
    "mal:59654": {},
    "tmdb_movie:810693": {},
    "tmdb_movie:1338799": {},
  },
};

assert.deepStrictEqual(parseAniBridgeDescriptor("tmdb_show:46260:s2"), {
  provider: "tmdb_show",
  id: "46260",
  scope: "s2",
  raw: "tmdb_show:46260:s2",
});
assert.strictEqual(parseAniBridgeDescriptor("unknown:1"), null);
assert.strictEqual(parseAniBridgeDescriptor("imdb_movie:not-imdb"), null);

const index = parseAniBridgePayload(fixture, 1000);
assert(index);
assert.strictEqual(index.schemaVersion, "3.0.3");
assert.strictEqual(index.generatedOn, "2026-09-24");
assert.strictEqual(index.records.size, 10);
assert.strictEqual(parseAniBridgePayload("not-json"), null);

assert.deepStrictEqual(mapAniBridgeEpisodeRange("53-104", "1-52", 53), [1]);
assert.deepStrictEqual(mapAniBridgeEpisodeRange("1-2", "1-4|2", 2), [3, 4]);
assert.deepStrictEqual(mapAniBridgeEpisodeRange("1-4", "1-2|-2", 3), [2]);
assert.deepStrictEqual(mapAniBridgeEpisodeRange("1-4", "1-2|-2", 5), []);
assert.deepStrictEqual(mapAniBridgeEpisodeRange("1-3", "1,3-4", 2), [3]);

const createContext = (handler) => ({
  axios: { get: handler },
  getBaseUrl: async () => "https://anime.test",
});

(async () => {
  const movieCalls = [];
  const movieContext = createContext(async (url) => {
    movieCalls.push(url);
    if (url === ANIBRIDGE_MAPPINGS_URL) return { data: fixture };
    throw new Error(`Unexpected URL: ${url}`);
  });
  const movie = await resolveAnimeMappings({
    providerContext: movieContext,
    anilistId: 5,
    malId: 5,
    isMovie: true,
  });
  assert.strictEqual(movie.imdbId, "tt0275277");
  assert.strictEqual(movie.imdbSource, "anibridge-v3");
  assert.deepStrictEqual(movie.ids.tmdbMovieIds, [11299]);
  assert.strictEqual(movieCalls.includes(PLEXANIBRIDGE_MAPPINGS_URL), false);

  const relatedMovieContext = createContext(async (url) => {
    if (url === ANIBRIDGE_MAPPINGS_URL) return { data: fixture };
    throw new Error(`Unexpected URL: ${url}`);
  });
  const jujutsuZero = await resolveAnimeMappings({
    providerContext: relatedMovieContext,
    anilistId: 131573,
    malId: 48561,
    isMovie: true,
  });
  const hiddenInventory = await resolveAnimeMappings({
    providerContext: relatedMovieContext,
    anilistId: 192809,
    malId: 59654,
    isMovie: true,
  });
  assert.deepStrictEqual(jujutsuZero.ids.tmdbMovieIds, [810693, 1338799]);
  assert.deepStrictEqual(hiddenInventory.ids.tmdbMovieIds, [810693, 1338799]);
  assert.strictEqual(jujutsuZero.imdbId, "tt14331144");
  assert.strictEqual(hiddenInventory.imdbId, "tt36956670");
  assert.deepStrictEqual(selectPrimaryTmdbId(jujutsuZero, true), {
    id: 810693,
    type: "movie",
  });
  assert.deepStrictEqual(selectPrimaryTmdbId(hiddenInventory, true), {
    id: 1338799,
    type: "movie",
  });

  const seriesCalls = [];
  const seriesContext = createContext(async (url) => {
    seriesCalls.push(url);
    if (url === ANIBRIDGE_MAPPINGS_URL) return { data: fixture };
    if (url === PLEXANIBRIDGE_MAPPINGS_URL) {
      return {
        data: {
          20: { anilist_id: 20, mal_id: 20, imdb_id: "tt0409591" },
        },
      };
    }
    throw new Error(`Unexpected URL: ${url}`);
  });
  const series = await resolveAnimeMappings({
    providerContext: seriesContext,
    anilistId: 20,
    malId: 20,
    isMovie: false,
  });
  assert.strictEqual(series.imdbId, "tt0409591");
  assert.strictEqual(series.imdbSource, "plexanibridge-v2");
  assert.strictEqual(series.lookupSource, "anilist-mal");
  assert.deepStrictEqual(series.ids.anilistIds, [20]);
  assert.deepStrictEqual(series.ids.malIds, [20]);
  assert.deepStrictEqual(series.ids.tmdbShowIds, [46260]);
  assert.deepStrictEqual(series.ids.tvdbShowIds, [78857]);
  assert.strictEqual(
    seriesCalls.filter((url) => url === ANIBRIDGE_MAPPINGS_URL).length,
    1,
  );
  assert.strictEqual(
    seriesCalls.filter((url) => url === PLEXANIBRIDGE_MAPPINGS_URL).length,
    1,
  );

  const reverseCalls = [];
  const reverseContext = createContext(async (url) => {
    reverseCalls.push(url);
    if (url === ANIBRIDGE_MAPPINGS_URL) return { data: fixture };
    if (url === PLEXANIBRIDGE_MAPPINGS_URL) {
      return {
        data: {
          20: { anilist_id: 20, mal_id: 20, imdb_id: "tt0409591" },
        },
      };
    }
    throw new Error(`Unexpected URL: ${url}`);
  });
  const reverse = await resolveExternalAnimeMappings({
    providerContext: reverseContext,
    tmdbId: 46260,
    isMovie: false,
  });
  assert.strictEqual(reverse.lookupSource, "external-reverse");
  assert.strictEqual(reverse.imdbId, "tt0409591");
  assert.strictEqual(reverse.imdbSource, "plexanibridge-v2");
  assert.deepStrictEqual(reverse.ids.anilistIds, [20]);
  assert.deepStrictEqual(reverse.ids.malIds, [20]);
  assert.deepStrictEqual(reverse.ids.tmdbShowIds, [46260]);
  assert.deepStrictEqual(reverse.ids.tvdbShowIds, [78857]);
  assert(
    reverse.targets.some(
      (target) =>
        target.provider === "anilist" &&
        target.id === "20" &&
        target.ranges["53-104"] === "53-104",
    ),
  );
  assert.strictEqual(
    reverseCalls.filter((url) => url === PLEXANIBRIDGE_MAPPINGS_URL).length,
    1,
  );

  const episodeMapping = resolveAniBridgeEpisodeMappings(series, 53);
  assert.strictEqual(episodeMapping.seasonNumber, 2);
  assert.deepStrictEqual(
    episodeMapping.mappings.find(
      (mapping) => mapping.provider === "tmdb_show" && mapping.id === "46260",
    ),
    {
      provider: "tmdb_show",
      id: "46260",
      scope: "s2",
      seasonNumber: 2,
      episodeNumbers: [53],
    },
  );

  const preferredMapping = resolveAniBridgeEpisodeMappings(
    {
      targets: [
        {
          provider: "tmdb_show",
          id: "95479",
          scope: "s1",
          raw: "tmdb_show:95479:s1",
          ranges: { "1-23": "25-47" },
        },
        {
          provider: "tmdb_show",
          id: "95479",
          scope: "s2",
          raw: "tmdb_show:95479:s2",
          ranges: { "1-23": "1-23" },
        },
      ],
    },
    1,
    { provider: "tmdb_show", id: "95479", scope: "s2" },
  );
  assert.strictEqual(preferredMapping.seasonNumber, 2);
  assert.deepStrictEqual(
    preferredMapping.mappings.filter(
      (mapping) => mapping.provider === "tmdb_show",
    ),
    [
      {
        provider: "tmdb_show",
        id: "95479",
        scope: "s2",
        seasonNumber: 2,
        episodeNumbers: [1],
      },
    ],
    "the selected season link must suppress conflicting TMDB mappings",
  );

  const extra = buildAniBridgeExtra(series);
  assert.strictEqual(extra.mappings.schemaVersion, "3.0.3");
  assert.strictEqual(extra.mappings.imdbSource, "plexanibridge-v2");
  assert(
    extra.mappings.targets.some((target) => target.provider === "tmdb_show"),
  );

  const aniZipFallbackCalls = [];
  const aniZipFallbackContext = createContext(async (url) => {
    aniZipFallbackCalls.push(url);
    if (url === ANIBRIDGE_MAPPINGS_URL) return { data: fixture };
    if (String(url).startsWith("https://api.ani.zip/mappings?")) {
      return {
        data: {
          mappings: {
            anilist_id: 30,
            mal_id: 30,
            type: "TV",
            thetvdb_id: 78857,
            themoviedb_id: "46260",
          },
        },
      };
    }
    throw new Error(`Unexpected URL: ${url}`);
  });
  const aniZipFallback = await resolveAnimeMappings({
    providerContext: aniZipFallbackContext,
    anilistId: 30,
    malId: 30,
    isMovie: false,
    includeLegacyImdb: false,
  });
  assert.deepStrictEqual(aniZipFallback.ids.tmdbShowIds, [46260]);
  assert.deepStrictEqual(
    aniZipFallback.targets.find(
      (target) => target.provider === "tmdb_show" && target.id === "46260",
    ),
    {
      provider: "tmdb_show",
      id: "46260",
      scope: "s2",
      raw: "tmdb_show:46260:s2",
      ranges: { "1-13": "1-13" },
    },
  );
  assert(
    aniZipFallbackCalls.some((url) =>
      String(url).startsWith("https://api.ani.zip/mappings?"),
    ),
  );

  const episodeCalls = [];
  const episodeContext = createContext(async (url) => {
    episodeCalls.push(url);
    if (url === "https://anime.test/info_api/99/") {
      return { data: { episodes_count: 104, anilist_id: 20, mal_id: 20 } };
    }
    if (url === ANIBRIDGE_MAPPINGS_URL) return { data: fixture };
    if (url.includes("/info_api/99/1?start_range=53&end_range=134")) {
      return { data: { episodes: [{ id: 9001, number: "53" }] } };
    }
    throw new Error(`Unexpected URL: ${url}`);
  });
  const episodes = await getEpisodes({
    url: "99|53|104",
    providerContext: episodeContext,
  });
  assert.strictEqual(episodes.length, 1);
  assert.strictEqual(episodes[0].episodeNumber, 53);
  assert.strictEqual(episodes[0].sourceEpisodeNumber, 53);
  assert.strictEqual(episodes[0].seasonNumber, 2);
  assert.deepStrictEqual(episodes[0].externalMappings[0].episodeNumbers, [53]);
  assert.strictEqual(episodeCalls.includes(PLEXANIBRIDGE_MAPPINGS_URL), false);

  const vegaCalls = [];
  const vegaContext = createContext(async (url) => {
    vegaCalls.push(url);
    if (url === "https://anime.test/info_api/99/") {
      return { data: { episodes_count: 104, anilist_id: 20, mal_id: 20 } };
    }
    if (url === ANIBRIDGE_MAPPINGS_URL) return { data: fixture };
    if (url.includes("/info_api/99/1?start_range=53&end_range=134")) {
      return { data: { episodes: [{ id: 9001, number: "53" }] } };
    }
    throw new Error(`Unexpected URL: ${url}`);
  });
  const firstVegaModule = executeVegaBundle("episodes.js");
  const secondVegaModule = executeVegaBundle("episodes.js");
  const firstVegaEpisodes = await firstVegaModule.getEpisodes({
    url: "99|53|104",
    providerContext: vegaContext,
  });
  const secondVegaEpisodes = await secondVegaModule.getEpisodes({
    url: "99|53|104",
    providerContext: vegaContext,
  });
  assert.strictEqual(firstVegaEpisodes[0].seasonNumber, 2);
  assert.strictEqual(secondVegaEpisodes[0].seasonNumber, 2);
  assert.strictEqual(
    vegaCalls.filter((url) => url === ANIBRIDGE_MAPPINGS_URL).length,
    1,
  );

  let fileEntry;
  let persistentDownloads = 0;
  const persistentFileCache = {
    read: async (key) => {
      assert.strictEqual(key, "anibridge-v3");
      return fileEntry;
    },
    write: async (key, value) => {
      assert.strictEqual(key, "anibridge-v3");
      fileEntry = { value, updatedAt: Date.now() };
    },
  };
  const persistentContext = () => ({
    axios: {
      get: async (url) => {
        assert.strictEqual(url, ANIBRIDGE_MAPPINGS_URL);
        persistentDownloads += 1;
        return { data: fixture };
      },
    },
    fileCache: persistentFileCache,
  });
  const mapMovie = (providerContext) =>
    resolveAnimeMappings({
      providerContext,
      anilistId: 5,
      isMovie: true,
      includeLegacyImdb: false,
    });
  const firstContext = persistentContext();
  await Promise.all([mapMovie(firstContext), mapMovie(firstContext)]);
  assert.strictEqual(persistentDownloads, 1, "in-flight lookups must be shared");
  const afterRestart = await mapMovie(persistentContext());
  assert.strictEqual(afterRestart.ids.tmdbMovieIds[0], 11299);
  assert.strictEqual(persistentDownloads, 1, "disk cache must survive a new context");

  fileEntry = { value: "invalid json", updatedAt: Date.now() };
  await mapMovie(persistentContext());
  assert.strictEqual(persistentDownloads, 2, "corrupt cache must refetch");
  fileEntry.updatedAt = Date.now() - 25 * 60 * 60 * 1000;
  await mapMovie(persistentContext());
  assert.strictEqual(persistentDownloads, 3, "expired cache must refetch");

  console.log("animeunity anibridge: OK");
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
