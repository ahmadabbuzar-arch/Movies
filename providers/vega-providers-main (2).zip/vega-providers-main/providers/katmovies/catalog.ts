export const catalog = [
  {
    title: "Latest",
    filter: "",
  },
  {
    title: "Netflix",
    filter: "/category/netflix",
  },
  {
    title: "Amazon Prime",
    filter: "/category/amazon-prime",
  },
];

export const genres = [
  {
    title: "Action",
    filter: "/category/action",
  },
  {
    title: "Crime",
    filter: "/category/crime",
  },
  {
    title: "Comedy",
    filter: "/category/comedy",
  },
  {
    title: "Drama",
    filter: "/category/drama",
  },
  {
    title: "Horror",
    filter: "/category/horror",
  },
  {
    title: "Family",
    filter: "/category/family",
  },
  {
    title: "Sci-Fi",
    filter: "/category/sifi",
  },
  {
    title: "Thriller",
    filter: "/category/triller",
  },
  {
    title: "Romance",
    filter: "/category/romance",
  },
  {
    title: "Fight",
    filter: "/category/fight",
  },
];
