import { Post, ProviderContext } from "../types";
import { getBaseUrl } from "../getBaseUrl";
import { throwProviderError } from "../providerErrors";

async function getWithWAF(
  url: string,
  axios: any,
  openWebView: any,
  headers: any,
): Promise<any> {
  const baseUrl = url.split("/").slice(0, 3).join("/");
  try {
    return await axios.get(url, { headers: { ...headers, Referer: baseUrl } });
  } catch (error: any) {
    if (error.response?.status === 403 && openWebView) {
      console.log(`WAF detected (403) for ${url}, using solver...`);
      const wafResult = await openWebView(baseUrl, {
        title: "Solve the captcha below and click done",
        description: "Required to bypass anti-bot protection.",
        headers: { ...headers, Referer: baseUrl },
        waitForCookie: "cf_clearance",
        force: true,
      });
      return await axios.get(url, {
        headers: { ...headers, Referer: baseUrl, Cookie: wafResult.cookie },
      });
    }
    throw error;
  }
}

export const getPosts = async function ({
  filter,
  page,
  signal,
  providerContext,
}: {
  filter: string;
  page: number;
  providerValue: string;
  signal: AbortSignal;
  providerContext: ProviderContext;
}): Promise<Post[]> {
  const { cheerio, axios, openWebView, commonHeaders } = providerContext;
  const baseUrl = await getBaseUrl("kat");
  const url = `${baseUrl + filter}/page/${page}/`;
  return posts({
    url,
    baseUrl,
    signal,
    cheerio,
    axios,
    openWebView,
    commonHeaders,
    operation: "posts",
  });
};

export const getSearchPosts = async function ({
  searchQuery,
  page,
  signal,
  providerContext,
}: {
  searchQuery: string;
  page: number;
  providerValue: string;
  signal: AbortSignal;
  providerContext: ProviderContext;
}): Promise<Post[]> {
  const { cheerio, axios, openWebView, commonHeaders } = providerContext;
  const baseUrl = await getBaseUrl("kat");
  const url = `${baseUrl}/page/${page}/?s=${searchQuery}`;
  return posts({
    url,
    baseUrl,
    signal,
    cheerio,
    axios,
    openWebView,
    commonHeaders,
    operation: "search posts",
  });
};

async function posts({
  url,
  baseUrl,
  signal,
  cheerio,
  axios,
  openWebView,
  commonHeaders,
  operation,
}: {
  url: string;
  baseUrl: string;
  signal: AbortSignal;
  cheerio: ProviderContext["cheerio"];
  axios: ProviderContext["axios"];
  openWebView: ProviderContext["openWebView"];
  commonHeaders: any;
  operation: string;
}): Promise<Post[]> {
  try {
    const res = await getWithWAF(url, axios, openWebView, commonHeaders);
    const data = res.data;
    const $ = cheerio.load(data);
    const catalog: Post[] = [];
    $(".recent-posts")
      .children()
      .map((i, element) => {
        const title = $(element).find("img").attr("alt");
        const link = $(element).find("a").attr("href");
        const image = $(element).find("img").attr("src");
        if (title && link && image) {
          const postUrl = new URL(link, `${baseUrl}/`);
          catalog.push({
            title: title.replace("Download", "").trim(),
            link: `${postUrl.pathname}${postUrl.search}${postUrl.hash}`,
            image: image,
          });
        }
      });
    return catalog;
  } catch (err) {
    throwProviderError("KatMovies", operation, err);
  }
}
