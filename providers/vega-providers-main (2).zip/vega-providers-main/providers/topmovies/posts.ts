import { Post, ProviderContext } from "../types";
import { getBaseUrl } from "../getBaseUrl";
import { throwProviderError } from "../providerErrors";

const headers = {
  Accept:
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
  "Cache-Control": "no-store",
  "Accept-Language": "en-US,en;q=0.9",
  DNT: "1",
  "sec-ch-ua":
    '"Not_A Brand";v="8", "Chromium";v="120", "Microsoft Edge";v="120"',
  "sec-ch-ua-mobile": "?0",
  "sec-ch-ua-platform": '"Windows"',
  "Sec-Fetch-Dest": "document",
  "Sec-Fetch-Mode": "navigate",
  "Sec-Fetch-Site": "none",
  "Sec-Fetch-User": "?1",
  "Upgrade-Insecure-Requests": "1",
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0",
};

export const getPosts = async function ({
  filter,
  page,
  signal,
  providerContext,
}: {
  filter: string;
  page: number;
  providerValue: string;
  signal: AbortSignal;
  providerContext: ProviderContext;
}): Promise<Post[]> {
  const baseUrl = await getBaseUrl("Topmovies");
  const url = `${baseUrl + filter}/page/${page}/`;

  return posts(baseUrl, url, signal, providerContext, "posts");
};

export const getSearchPosts = async function ({
  searchQuery,
  page,
  signal,
  providerContext,
}: {
  searchQuery: string;
  page: number;
  providerValue: string;
  signal: AbortSignal;
  providerContext: ProviderContext;
}): Promise<Post[]> {
  const baseUrl = await getBaseUrl("Topmovies");
  const url = `${baseUrl}/search/${searchQuery}/page/${page}/`;
  return posts(baseUrl, url, signal, providerContext, "search posts");
};

async function posts(
  baseUrl: string,
  url: string,
  signal: AbortSignal,
  providerContext: ProviderContext,
  operation: string,
): Promise<Post[]> {
  try {
    const { axios, cheerio } = providerContext;
    const res = await axios.get(url, { headers, signal });
    const data = res.data;
    const $ = cheerio.load(data);
    const catalog: Post[] = [];
    $(".post-cards")
      .find("article")
      .map((i, element) => {
        const title = $(element).find("a").attr("title");
        const link = $(element).find("a").attr("href");
        const image =
          $(element).find("img").attr("data-src") ||
          $(element).find("img").attr("src") ||
          "";
        if (title && link) {
          catalog.push({
            title: title.replace("Download", "").trim(),
            link: (() => {
              const postUrl = new URL(link, `${baseUrl}/`);
              return `${postUrl.pathname}${postUrl.search}${postUrl.hash}`;
            })(),
            image: image,
          });
        }
      });
    // console.log(catalog);
    return catalog;
  } catch (err) {
    throwProviderError("TopMovies", operation, err);
  }
}
