import { ProviderContext, Stream } from "../types";
import { throwProviderError } from "../providerErrors";

export const getStream = async ({
  link: url,
  providerContext,
}: {
  link: string;
  providerContext: ProviderContext;
}): Promise<Stream[]> => {
  try {
    const { axios, cheerio, commonHeaders: headers } = providerContext;
    let downloadLink = await modExtractor(url, providerContext);

    // console.log(downloadLink.data);

    const ddl = downloadLink?.data?.match(/content="0;url=(.*?)"/)?.[1] || url;

    console.log("ddl", ddl);
    // console.log(ddl);
    const driveLink = await isDriveLink(ddl);
    const ServerLinks: Stream[] = [];

    const driveRes = await axios.get(driveLink, { headers });
    const driveHtml = driveRes.data;
    const $drive = cheerio.load(driveHtml);

    //instant link
    try {
      const seed = $drive(".btn-danger").attr("href") || "";
      const instantToken = seed.split("=")[1];
      //   console.log('InstantToken', instantToken);
      const InstantFromData = new FormData();
      InstantFromData.append("keys", instantToken);
      const videoSeedUrl = seed.split("/").slice(0, 3).join("/") + "/api";
      //   console.log('videoSeedUrl', videoSeedUrl);
      const instantLinkRes = await fetch(videoSeedUrl, {
        method: "POST",
        body: InstantFromData,
        headers: {
          "x-token": videoSeedUrl,
        },
      });
      const instantLinkData = await instantLinkRes.json();
      //   console.log('instantLinkData', instantLinkData);
      if (instantLinkData.error === false) {
        const instantLink = instantLinkData.url;
        ServerLinks.push({
          server: "G-Drive (download only)",
          link: instantLink,
          type: "mkv",
        });
      } else {
        console.log("Instant link not found", instantLinkData);
      }
    } catch (err) {
      console.log("Instant link not found", err);
    }

    //*******
    //instant link 2
    //*******
    try {
      const seed = $drive(".btn-danger").attr("href") || "";
      const newLinkRes = await fetch(seed, {
        method: "HEAD",
        headers,
        redirect: "manual",
      });
      let newLink = seed;
      if (newLinkRes.status >= 300 && newLinkRes.status < 400) {
        newLink = newLinkRes.headers.get("location") || seed;
      } else if (newLinkRes.url && newLinkRes.url !== seed) {
        // Fallback: check if URL changed (redirect was followed)
        newLink = newLinkRes.url || newLinkRes.url;
      } else {
        newLink = newLinkRes.headers.get("location") || seed;
      }
      console.log("Gdrive-Instant-2 link", newLink?.split("?url=")[1]);
      ServerLinks.push({
        server: "G-Drive (download only)",
        link: newLink?.split("?url=")[1] || newLink,
        type: "mkv",
      });
    } catch (err) {
      console.log("Instant link not found", err);
    }

    // resume link
    try {
      const resumeDrive = driveLink.replace("/file", "/zfile");
      //   console.log('resumeDrive', resumeDrive);
      const resumeDriveRes = await axios.get(resumeDrive, { headers });
      const resumeDriveHtml = resumeDriveRes.data;
      const $resumeDrive = cheerio.load(resumeDriveHtml);
      const resumeLink = $resumeDrive(".btn-success").attr("href");
      //   console.log('resumeLink', resumeLink);
      if (resumeLink) {
        ServerLinks.push({
          server: "ResumeCloud",
          link: resumeLink,
          type: "mkv",
        });
      }
    } catch (err) {
      console.log("Resume link not found");
    }

    // Base page worker
    try {
      const baseWorkerStream = $drive(".btn-success");
      baseWorkerStream.each((i, el) => {
        const link = (el as any).attribs?.href;
        if (link) {
          ServerLinks.push({
            server: "Resume Worker " + (i + 1),
            link: link,
            type: "mkv",
          });
        }
      });
    } catch (err) {
      console.log("Base page worker link not found", err);
    }

    // CF workers type 1
    try {
      const cfWorkersLink = driveLink.replace("/file", "/wfile") + "?type=1";
      const cfWorkersRes = await axios.get(cfWorkersLink, { headers });
      const cfWorkersHtml = cfWorkersRes.data;
      const $cfWorkers = cheerio.load(cfWorkersHtml);
      const cfWorkersStream = $cfWorkers(".btn-success");
      cfWorkersStream.each((i, el) => {
        const link = (el as any).attribs?.href;
        if (link) {
          ServerLinks.push({
            server: "Cf Worker 1." + i,
            link: link,
            type: "mkv",
          });
        }
      });
    } catch (err) {
      console.log("CF workers link not found", err);
    }

    // CF workers type 2
    try {
      const cfWorkersLink = driveLink.replace("/file", "/wfile") + "?type=2";
      const cfWorkersRes = await axios.get(cfWorkersLink, { headers });
      const cfWorkersHtml = cfWorkersRes.data;
      const $cfWorkers = cheerio.load(cfWorkersHtml);
      const cfWorkersStream = $cfWorkers(".btn-success");
      cfWorkersStream.each((i, el) => {
        const link = (el as any).attribs?.href;
        if (link) {
          ServerLinks.push({
            server: "Cf Worker 2." + i,
            link: link,
            type: "mkv",
          });
        }
      });
    } catch (err) {
      console.log("CF workers link not found", err);
    }

    console.log("ServerLinks", ServerLinks);
    return ServerLinks;
  } catch (err) {
    throwProviderError("UHDMovies", "stream", err);
  }
};

const isDriveLink = async (ddl: string) => {
  if (ddl.includes("drive")) {
    const driveLeach = await fetch(ddl);
    const driveLeachData = await driveLeach.text();
    const pathMatch = driveLeachData.match(
      /window\.location\.replace\("([^"]+)"\)/,
    );
    const path = pathMatch?.[1];
    const mainUrl = ddl.split("/")[2];
    console.log(`driveUrl = https://${mainUrl}${path}`);
    return `https://${mainUrl}${path}`;
  } else {
    return ddl;
  }
};

async function getWithWAF(
  url: string,
  axios: any,
  openWebView: any,
  headers: any,
): Promise<any> {
  const baseUrl = url.split("/").slice(0, 3).join("/");
  try {
    return await axios.get(url, { headers: { ...headers, Referer: baseUrl } });
  } catch (error: any) {
    if (error.response?.status === 403 && openWebView) {
      console.log(`WAF detected (403) for ${url}, using solver...`);
      const wafResult = await openWebView(baseUrl, {
        title: "Solve the captcha below and click done",
        description: "Required to bypass anti-bot protection.",
        headers: { ...headers, Referer: baseUrl },
        waitForCookie: "cf_clearance",
        force: true,
      });
      return await axios.get(url, {
        headers: { ...headers, Referer: baseUrl, Cookie: wafResult.cookie },
      });
    }
    throw error;
  }
}

async function modExtractor(url: string, providerContext: ProviderContext) {
  const { axios, cheerio, openWebView } = providerContext;
  try {
    const wpHttp = url.split("sid=")[1];
    var bodyFormData0 = new FormData();
    bodyFormData0.append("_wp_http", wpHttp);
    const res = await fetch(url.split("?")[0], {
      method: "POST",
      body: bodyFormData0,
    });
    const data = await res.text();
    // console.log('', data);
    const html = data;
    const $ = cheerio.load(html);

    // find input with name="_wp_http2"
    const wpHttp2 = $("input").attr("name", "_wp_http2").val();

    // console.log('wpHttp2', wpHttp2);

    // form data
    var bodyFormData = new FormData();
    bodyFormData.append("_wp_http2", wpHttp2 as string);
    const formUrl1 = $("form").attr("action");
    const formUrl = formUrl1 || url.split("?")[0];

    const res2 = await fetch(formUrl, {
      method: "POST",
      body: bodyFormData,
    });
    const html2: any = await res2.text();
    const linkMatch = html2.match(/setAttribute\("href",\s*"(.*?)"/);
    if (!linkMatch) return null;
    const link = linkMatch[1];
    console.log(link);
    const cookie = link.split("=")[1];
    console.log("cookie", cookie);

    const downloadLink = await getWithWAF(link, axios, openWebView, {
      Referer: formUrl,
      Cookie: `${cookie}=${wpHttp2}`,
    });
    return downloadLink;
  } catch (err) {
    console.log("modGetStream error", err);
  }
}
