import { EpisodeLink, ProviderContext } from "../types";
import {
  enrichCinemetaEpisodes,
  getCinemetaMeta,
  readCinemetaContext,
} from "../getCinemetaMeta";
import { enrichEpisodesWithSkipTimings } from "../theintrodb";
import { getWithWAF } from "./helper";

const formatEpisodeTitle = (fileName: string): string => {
  try {
    // Match patterns like S03E01, S03E1, s03e01, etc.
    const match = fileName.match(/S(\d+)E(\d+)/i);
    if (match) {
      const season = match[1].padStart(2, "0");
      const episode = match[2].padStart(2, "0");
      return `S${season} E${episode}`;
    }
    return fileName;
  } catch {
    return fileName;
  }
};

export const getEpisodes = async function ({
  url,
  providerContext,
}: {
  url: string;
  providerContext: ProviderContext;
}): Promise<EpisodeLink[]> {
  const {
    axios,
    cheerio,
    commonHeaders: headers,
    openWebView,
  } = providerContext;
  console.log("getEpisodeLinks", url);
  try {
    const context = readCinemetaContext(url);
    const requestUrl = context.requestUrl;
    const parsedUrl = new URL(requestUrl);
    const baseUrl = parsedUrl.origin;
    const id = parsedUrl.pathname.split("/").filter(Boolean).pop() || "";
    const apiUrl = `${baseUrl}/api/packs/${id}`;
    console.log("apiUrl:", apiUrl);

    const enrich = async (episodes: EpisodeLink[]): Promise<EpisodeLink[]> => {
      if (!context.imdbId || !context.season) return episodes;
      let enriched = episodes;
      try {
        const cinemeta = await getCinemetaMeta(
          context.imdbId,
          "series",
          providerContext,
        );
        if (cinemeta) {
          enriched = enrichCinemetaEpisodes(
            episodes,
            cinemeta.videos || [],
            context.season,
          );
        }
      } catch (e) {
        console.warn("1CineVood: Cinemeta episode lookup failed", e);
      }

      const skipTimings = await providerContext.kvStore?.get<boolean>("1cinevood_skipTimings");
      if (skipTimings ?? true) {
        try {
          enriched = await enrichEpisodesWithSkipTimings(
            enriched,
            context.imdbId,
            context.season,
            providerContext,
          );
        } catch (e) {
          console.warn("1CineVood: Skip timings lookup failed", e);
        }
      }
      return enriched;
    };

    let res;
    try {
      res = await getWithWAF(apiUrl, axios, openWebView, headers);
    } catch (error: any) {
      // If 404, try alternative API endpoint
      if (error.response?.status === 404) {
        const alternativeUrl = `${baseUrl}/api/s/${id}/`;
        console.log("Trying alternative URL:", alternativeUrl);

        const altRes = await getWithWAF(
          alternativeUrl,
          axios,
          openWebView,
          headers,
        );

        let altData = altRes?.data;
        if (typeof altData === "string") {
          try {
            altData = JSON.parse(altData.replace(/<[^>]+>/g, "").trim());
          } catch {}
        }

        // Check if hubcloud is available
        if (altData?.hasHubcloud) {
          const hubcloudUrl = `${baseUrl}/api/s/${id}/hubcloud`;
          return enrich([
            {
              title: formatEpisodeTitle(altData.fileName || "Movie"),
              link: hubcloudUrl,
            },
          ]);
        }

        return [];
      }
      throw error;
    }

    const episodes: EpisodeLink[] = [];

    let packData = res?.data;
    if (typeof packData === "string") {
      try {
        packData = JSON.parse(packData.replace(/<[^>]+>/g, "").trim());
      } catch {}
    }

    const items = packData?.pack?.items || [];

    for (const item of items) {
      if (item.file_name && item.hubcloud_link) {
        episodes.push({
          title: formatEpisodeTitle(item.file_name),
          link: item.hubcloud_link,
        });
      }
    }

    const quickDownload = await providerContext.kvStore?.get<boolean>("1cinevood_quickDownload");
    const enrichedEpisodes = await enrich(episodes);
    return enrichedEpisodes.map((e) => ({
      ...e,
      quickDownload: quickDownload ?? true,
    }));
  } catch (err) {
    throw err;
  }
};
